import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  bool animation=false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  Future.delayed(Duration(seconds: 2)).then((value) {
    setState(() {
      animation=!animation;
    });
  });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: AnimatedContainer(
            duration: Duration(seconds: 3),
            onEnd: () {
              setState(() {
                animation=!animation;
              });
            },
          height: animation?400:100,
          width: animation?400:100,
          color: animation?Colors.green:Colors.yellow,
          curve: Curves.slowMiddle,
        ),
      ),
    );
  }
}
