
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


void main()
{
  runApp(MaterialApp(home:first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  int value=0;
  int highscore=0;
  SharedPreferences ?  prefs;//database object create

  @override
  void initState() {
    super.initState();
    get();
  }
  get()
  async {
    prefs=await SharedPreferences.getInstance();//dtabase crete
    setState(() {
      highscore= prefs!.getInt('storevariable')??0;//value gate karavi
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Shared prefrence",style: TextStyle(fontSize: 20),)),
      body: Center(
        child: Column(
          children: [

            ElevatedButton(onPressed: () {
              setState(() {
                value++;
              });
            }, child: Text("+",style: TextStyle(fontSize: 20),)),
            Text("$value"),
            ElevatedButton(onPressed: () {
              setState(() {
                value--;
              });
            }, child: Text("-",style: TextStyle(fontSize: 20),)),

            ElevatedButton(onPressed: () async {

               if(value>highscore)
               {
                 await prefs!.setInt('storevariable', value);//value set kari storevariable name na variable ma
                 // highscore=value;
               }


             setState(() {
               highscore= prefs!.getInt('storevariable')??0;//pachi value get karavi niche print karravva mate
             });
            }, child: Text("Submit",style: TextStyle(fontSize: 20),)),

            Text("highscore = $highscore"),

          ],
        ),
      ),
    );
  }
}
