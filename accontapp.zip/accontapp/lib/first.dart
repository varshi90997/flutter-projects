import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: Text(
          "SUPER NOTE",
        style: TextStyle(color: Colors.white)),
        actions: [
          SizedBox(
            width: 10,
          ),
          IconButton(onPressed: () {}, icon: Icon(Icons.search)),
          PopupMenuButton(
            itemBuilder: (context) => [],
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(child: Icon(Icons.add_box_outlined),onPressed: () {
        showDialog(context: context, builder: (context) {
          return AlertDialog(actions: [
                Column(children: [
                  SizedBox(width: 20,),
                  Center(child: Container(height: 50,padding: EdgeInsets.only(left: 70,top: 10),width: double.infinity,margin: EdgeInsets.only(bottom: 10),color: Colors.deepPurple,child: Text("Add new account",style: TextStyle(fontSize: 20,color: Colors.white)),)),
                  TextField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter a search term',
                    ),
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      ElevatedButton(style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                          padding: MaterialStateProperty.all<EdgeInsets>(EdgeInsets.fromLTRB(12, 4,12, 4)),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                  side: BorderSide(color: Colors.deepPurple)
                              )
                          )
                      ),onPressed: () {

                      }, child: Text("cancel",style: TextStyle(fontSize: 20,color: Colors.deepPurple),)),
                      ElevatedButton(style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  side: BorderSide(color: Colors.deepPurple)
                              )
                          )
                      ),onPressed: () {

                      }, child: Text("save",style: TextStyle(fontSize: 20,color: Colors.deepPurple),)),
                    ],
                  )
                ],)
          ],);
        },);
      },),
      drawer: Drawer(),

    );
  }
}
