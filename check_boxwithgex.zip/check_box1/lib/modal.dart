import 'package:get/get.dart';

class model extends GetxController
{
  RxBool t1=false.obs;
  RxBool t2=false.obs;
  RxBool t3=false.obs;
  RxInt ans=0.obs;
  RxString khali="".obs;
  Rx<StringBuffer> sp=StringBuffer().obs;
  Rx<StringBuffer> sp1=StringBuffer().obs;
  Rx<StringBuffer> sp2=StringBuffer().obs;

  void ftotal()
  {

  }
}