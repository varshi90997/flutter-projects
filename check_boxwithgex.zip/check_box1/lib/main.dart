import 'package:check_box1/first.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

void main()
{
  runApp(GetMaterialApp(home: first(),));
}