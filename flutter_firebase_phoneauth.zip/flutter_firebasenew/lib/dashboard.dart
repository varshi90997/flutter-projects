import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebasenew/crude/fone.dart';

import 'package:google_sign_in/google_sign_in.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  User? user;
  @override
  void initState() {//1-pelethi login karelu nathi[2 method thi] e check karva mate,,,login hoy to bija page ma vay jase
    // TODO: implement initState
    super.initState();
    user = FirebaseAuth.instance.currentUser;
    if(user==null)
    {
      print("not login");
    }
    else
    {
      print(user?.email);
      print(user?.uid);
      print(user?.displayName);
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
          appBar: AppBar(
            actions: [
              IconButton(onPressed: () async {

                await GoogleSignIn().signOut();//2-sign out mate vpray che
                await FirebaseAuth.instance.signOut();
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return first();
                },));
              }, icon: Icon(Icons.logout))
            ],
          ),
      body:Column(children: [
        Text("${user?.email}"),
        Text("${user?.displayName}"),
        Text("${user?.uid}"),
      ],) ,
    );
  }
}
