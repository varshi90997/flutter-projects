import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebasenew/crude/fone.dart';
import 'package:flutter_firebasenew/dashboard.dart';
import 'package:google_sign_in/google_sign_in.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    // options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MaterialApp(home: first(),debugShowCheckedModeBanner: false,));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {

  Future<UserCredential> signInWithGoogle() async {//2-google and firebase signin mate vapray che a function
    // Trigger the authentication flow
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

    // Create a new credential
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );

    // Once signed in, return the UserCredential
    return await FirebaseAuth.instance.signInWithCredential(credential);
  }
  @override
  void initState() {//2-
    // TODO: implement initState
    super.initState();
    final user = FirebaseAuth.instance.currentUser;//1-pelethi login karelu nathi[2 method thi] e check karva mate,,,login hoy to bija page ma vay jase
    if(user==null)
      {
        print("not login");
      }
    else
    {
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return Dashboard();
      },));
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body:ElevatedButton(onPressed: () {

        signInWithGoogle().then((value)//3-login thay jay to second page ma javanu
        {
         print(value);
         if(value!=null)
           {
             Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
               return Dashboard();
             },));
           }
        });
      }, child: Text("data"))
    );
  }
}
