import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();

  // List<user> userlist=[];
  DatabaseReference ref = FirebaseDatabase.instance.ref("student");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          TextField(controller: t1,),
          TextField(controller: t2,),
          ElevatedButton(onPressed: () async{
            await ref.push().set({
              "name": "${t1.text}",
              "age": "${t2.text}",
            });
          }, child: Text("submit"))
        ],
      ),
    );
  }
}
