import 'package:flutter/material.dart';
import 'package:page_deleter/forth.dart';
import 'package:page_deleter/model.dart';

class third extends StatefulWidget {
  model m;
  third(this.m);



  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(children: [

        Text("${widget.m.f1[2]}"),
        Text("${widget.m.f2[2]}"),
        Text("${widget.m.f3[3]}"),
        Text("${widget.m.f4[4]}"),

        ElevatedButton(onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return forth(widget.m);
          },));
        }, child: Text("forth page"))
      ]),
    );
  }
}
