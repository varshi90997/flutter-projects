import 'package:flutter/material.dart';
import 'package:page_deleter/model.dart';
import 'package:page_deleter/third.dart';

class forth extends StatefulWidget {
  model m;
  forth(this.m);



  @override
  State<forth> createState() => _forthState();
}

class _forthState extends State<forth> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(children: [

        Text("${widget.m.f1[2]}"),
        Text("${widget.m.f2[2]}"),
        Text("${widget.m.f3[3]}"),
        Text("${widget.m.f4[4]}"),

        ElevatedButton(onPressed: () {
          // Navigator.push(context, MaterialPageRoute(builder: (context) {
          //   return third(widget.m);
          // },));
        }, child: Text("forth page"))
      ]),
    );
  }
}
