class model
{
  List<int> f1=[10,20,30,40];
  List<String> f2=["sahil","varshil","rumit","gsf"];
  List<double> f3=[12.2,12.4,4.5,4.5];   //poin vali velue mate
  List<bool> f4=[false,true];
  Set<int> literalSpecialNumbers = {1, 4, 6};
 }