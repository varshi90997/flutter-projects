import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:page_deleter/model.dart';
import 'package:page_deleter/second.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  model m=model();//memory apvi pade
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 100,
          height: 100,
          child: Text("${m.f1[0]}"),
        ),

        Text("${m.f2[1]}"),
        Text("${m.f3[1]}"),
        Text("${m.f4[1]}"),
        Text("${m.literalSpecialNumbers}"),

        ElevatedButton(onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return second(m);
          },));
        }, child: Text("second page"))
      ],
    );
  }
}
