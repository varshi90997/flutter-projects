import 'package:flutter/material.dart';
import 'package:page_deleter/model.dart';
import 'package:page_deleter/third.dart';

class second extends StatefulWidget {
  model m;
  second(this.m);



  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(children: [

        Text("${widget.m.f1[1]}"),
        Text("${widget.m.f2[1]}"),
        Text("${widget.m.f3[1]}"),
        Text("${widget.m.f4[1]}"),

        ElevatedButton(onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
              return third(widget.m);
          },));
        }, child: Text("Third page"))
      ]),
    );
  }
}
