package com.example.page_deleter;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
