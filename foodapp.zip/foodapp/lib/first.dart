import 'package:diamond_bottom_bar/diamond_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/model.dart';

void main()
{
  runApp(MaterialApp(debugShowCheckedModeBanner: false,home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> with TickerProviderStateMixin{
  TabController? tabController;//object banavyo


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabController=TabController(length: 4, vsync: this);//standard tapcontrioller assingn karyu

    tabController!.addListener(() {
      print("${tabController!.index}");//output ma print karravva mate
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent,title: Text("Tab bar",style: TextStyle(color: Colors.black54)),elevation: 0,

        // flexibleSpace: Container(decoration: BoxDecoration( color: const Color(0xff7c94b6),image: DecorationImage(image: AssetImage("img/bacground1.jpg"), colorFilter: new ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.dstATop),fit: BoxFit.cover)),),


        bottom: TabBar(
          indicator: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.white),
          controller: tabController,


          tabs: [
            Tab(child: Container(decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/burger.png")),borderRadius: BorderRadius.circular(20)),),),
            Tab(child: Container(decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/icecream.png")),borderRadius: BorderRadius.circular(20)),),),
            Tab(child: Container(decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/pasta.png")),borderRadius: BorderRadius.circular(20)),),),
            Tab(child: Container(decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/pizza.png")),borderRadius: BorderRadius.circular(20)),),),
          ],
        ),

      ),
      body:Container(
          decoration: BoxDecoration( color: const Color(0xff7c94b6),image: DecorationImage(image: AssetImage("img/bacground1.jpg"), colorFilter: new ColorFilter.mode(Colors.black.withOpacity(0.8), BlendMode.dstATop),fit: BoxFit.cover)),
        child: TabBarView(controller: tabController,children: [
          second(),
          third(),
          fourth(),
          fifth(),
        ]),
      ) ,
    );
  }
}

class second extends StatefulWidget {
  const second({Key? key}) : super(key: key);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  List l=["1","2","3","4","5","6","7","8","9","10"];
  @override
  Widget build(BuildContext context) {
    int _selectedIndex = 0;
    late Widget _selectedWidget;
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body:  GridView.builder(itemCount: op.imgList.length,gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder: (context, index) {
        return Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: 25,bottom: 20,left: 8),
                height: 130,
                width: 100,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.tealAccent,),

              ),
              Column(
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.only(top: 80,left: 25),
                    decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/${op.imgList[index]}"),fit: BoxFit.fill),borderRadius: BorderRadius.circular(20)),

                    child: Text("burger",style: TextStyle(fontSize: 15,color: Colors.black),),
                  ),
                  Container(   margin: EdgeInsets.only(),height: 21,width: 90,decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.yellow),
                      padding: EdgeInsets.only(left: 7),
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text("24",style: TextStyle(fontSize: 15)),
                          Text("24",style: TextStyle(fontSize: 15)),
                        ],
                      )
                  )
                ],
              ),

            ]
        );
      },),
      bottomNavigationBar: DiamondBottomNavigation(
        itemIcons: const [
          Icons.home,
          Icons.notifications,
          Icons.message,
          Icons.account_box,
        ],
        centerIcon: Icons.place,
        selectedIndex: _selectedIndex, onItemPressed: (int ) {  },
      ),
    );
  }
}
class third extends StatefulWidget {
  const third({Key? key}) : super(key: key);

  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {
  List l=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body:  GridView.builder(itemCount: l.length,gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder: (context, index) {
        return Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: 25,bottom: 20,left: 8),
                height: 130,
                width: 100,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.tealAccent,),

              ),
              Column(
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.only(top: 80,left: 25),
                    decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/burger.png"),fit: BoxFit.fill),borderRadius: BorderRadius.circular(20)),

                    child: Text("burger",style: TextStyle(fontSize: 15,color: Colors.black),),
                  ),
                  Container(   margin: EdgeInsets.only(),height: 21,width: 90,decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.yellow),
                      padding: EdgeInsets.only(left: 7),
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text("24",style: TextStyle(fontSize: 15)),
                          Text("24",style: TextStyle(fontSize: 15)),
                        ],
                      )
                  )
                ],
              ),

            ]
        );
      },),
    );
  }
}
class fourth extends StatefulWidget {
  const fourth({Key? key}) : super(key: key);

  @override
  State<fourth> createState() => _fourthState();
}

class _fourthState extends State<fourth> {
  List l=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body:  GridView.builder(itemCount: l.length,gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder: (context, index) {
        return Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: 25,bottom: 20,left: 8),
                height: 130,
                width: 100,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.tealAccent,),

              ),
              Column(
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.only(top: 80,left: 25),
                    decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/burger.png"),fit: BoxFit.fill),borderRadius: BorderRadius.circular(20)),

                    child: Text("burger",style: TextStyle(fontSize: 15,color: Colors.black),),
                  ),
                  Container(   margin: EdgeInsets.only(),height: 21,width: 90,decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.yellow),
                      padding: EdgeInsets.only(left: 7),
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text("24",style: TextStyle(fontSize: 15)),
                          Text("24",style: TextStyle(fontSize: 15)),
                        ],
                      )
                  )
                ],
              ),

            ]
        );
      },),
    );
  }
}

class fifth extends StatefulWidget {
  const fifth({Key? key}) : super(key: key);

  @override
  State<fifth> createState() => _fifthState();
}

class _fifthState extends State<fifth> {
  List l=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body:  GridView.builder(itemCount: l.length,gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder: (context, index) {
        return Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: 25,bottom: 20,left: 8),
                height: 130,
                width: 100,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.tealAccent,),

              ),
              Column(
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.only(top: 80,left: 25),
                    decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/burger.png"),fit: BoxFit.fill),borderRadius: BorderRadius.circular(20)),

                    child: Text("burger",style: TextStyle(fontSize: 15,color: Colors.black),),
                  ),
                  Container(   margin: EdgeInsets.only(),height: 21,width: 90,decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.yellow),
                      padding: EdgeInsets.only(left: 7),
                      child:Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text("24",style: TextStyle(fontSize: 15)),
                          Text("24",style: TextStyle(fontSize: 15)),
                        ],
                      )
                  )
                ],
              ),

            ]
        );
      },),
    );
  }
}





