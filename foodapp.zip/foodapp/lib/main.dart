import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/first.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}

