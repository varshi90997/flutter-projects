class op
{
  static List<String> imgList = [
    "fbu.jpg",
    "f2.jpg",
    "f3.jpg",
    "f4.jpg",
    "f5.jpg",
  ];
}