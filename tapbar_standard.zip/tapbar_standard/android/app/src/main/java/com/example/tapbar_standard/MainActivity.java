package com.example.tapbar_standard;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
