import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(debugShowCheckedModeBanner: false,home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> with TickerProviderStateMixin{
  TabController? tabController;//object banavyo
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    tabController=TabController(length: 3, vsync: this);//standard tapcontrioller assingn karyu

    tabController!.addListener(() {
      print("${tabController!.index}");//output ma print karravva mate
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tab bar",style: TextStyle(color: Colors.black54)),
        actions: [
          PopupMenuButton(itemBuilder: (context) => [
            PopupMenuItem(child: Text("first-tab"),onTap: () => tabController!.animateTo(0)),
            PopupMenuItem(child: Text("second-tab"),onTap: () => tabController!.animateTo(1)),
            PopupMenuItem(child: Text("third-tab"),onTap: () => tabController!.animateTo(2)),
          ],)
        ],
        bottom: TabBar(
          controller: tabController,

          indicatorColor: Colors.black54,
          isScrollable: true,
          labelColor: Colors.black54,
          tabs: [
            Tab(text: "first-tab",icon:Icon(Icons.ac_unit)),
            Tab(text: "second-tab",icon:Icon(Icons.account_balance)),
            Tab(text: "third-tab",icon:Icon(Icons.account_box_outlined)),
          ],
        ),

      ),
      body:TabBarView(controller: tabController,children: [
        second(),
        third(),
        fourth(),
      ]) ,
    );
  }
}

class second extends StatefulWidget {
  const second({Key? key}) : super(key: key);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  List l=["1","2","3","4","5","6","7","8","9","10"];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(itemCount: l.length,gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder: (context, index) {
      return Container(
        height: 300,
        width: 300,
        margin: EdgeInsets.all(10),
        color: Colors.blueGrey,
        child: Center(child: Text("${l[index]}",style: TextStyle(fontSize: 20,color: Colors.white),)),
      );
    },);
  }
}
class third extends StatefulWidget {
  const third({Key? key}) : super(key: key);

  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {
  List l=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
  @override
  Widget build(BuildContext context) {
    return ListView.builder(scrollDirection: Axis.vertical,itemCount: l.length,itemBuilder: (context, index) {
      return ListTile(
        leading: Text("${l[index]}"),
      );
    },);
  }
}
class fourth extends StatefulWidget {
  const fourth({Key? key}) : super(key: key);

  @override
  State<fourth> createState() => _fourthState();
}

class _fourthState extends State<fourth> {
  List l=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
  @override
  Widget build(BuildContext context) {
    return PageView.builder(itemBuilder: (context, index) {
      return Container(
        height: 300,
        width: 300,
        margin: EdgeInsets.all(10),
        color: Colors.blueGrey,
        child: Center(child: Text("${l[index]}",style: TextStyle(fontSize: 20,color: Colors.white),)),
      );
    },);
  }
}




