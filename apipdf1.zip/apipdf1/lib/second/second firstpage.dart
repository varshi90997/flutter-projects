import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class sfirstpage extends StatefulWidget {
  const sfirstpage({Key? key}) : super(key: key);

  @override
  State<sfirstpage> createState() => _sfirstpageState();
}

class _sfirstpageState extends State<sfirstpage> {
  var size,height,width;
  String t="fruits";
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  TextEditingController t3=TextEditingController();
  TextEditingController t4=TextEditingController();
  @override
  Widget build(BuildContext context)
  {
    size = MediaQuery.of(context).size;
    // height = size.height;
    height=MediaQuery.of(context).size.height *1;//2=100%, 1=50%
    width = size.width;
    return Scaffold(
      appBar: AppBar(),
      body:Column(
        children: [
          Container(
              margin: EdgeInsets.all(10),
              height: height/15,
              width:double.infinity,
              color: Colors.black54,
              child:Center(child:  Text(" EDITE CATEGORY",style: TextStyle(color: Colors.white,fontSize: 20)),)
          ),
          Container(
              padding: EdgeInsets.all(15),
              height: height/16,
              width:double.infinity,
              child: Text("Select category",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold,color: Colors.black),)
          ),
          Container(
            margin: EdgeInsets.all(height/110),
            height: height/15,

            width: double.infinity,
            decoration: BoxDecoration(color: Colors.black12,borderRadius: BorderRadius.circular(10)),
            child: DropdownButton(
              value: "$t",
              isExpanded: true,
              elevation: 16,
              icon: Icon(Icons.arrow_drop_down_sharp,size: 40,),
              borderRadius: BorderRadius.circular(10),
              items: [
                DropdownMenuItem(child: Text("fruits"),value: "fruits",),
                DropdownMenuItem(child: Text("vegatable"),value: "vegatable",),
                DropdownMenuItem(child: Text("flowers"),value: "flowers",),
              ],
              onChanged: (value) {
                    setState(() {
                      t=value!;
                    });
            },),
          ),

          Container(
              padding: EdgeInsets.all(15),
              height: height/15,
              width:double.infinity,
              child: Text("Name",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
          ),
          Padding(
            padding:EdgeInsets.only(left: width/30,right:width/30 ),
            child: TextField(
              controller: t2,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.black12,
                border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(5)
                ),
              ),
            ),
          ),

          Container(
              padding: EdgeInsets.all(15),
              height: height/14,
              width:double.infinity,
              child: Text("Mrp",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
          ),
          Padding(
            padding:EdgeInsets.only(left: width/30,right:width/30 ),
            child: TextField(
              controller: t3,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.black12,
                border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(5)
                ),
              ),
            ),
          ),

          Container(
              padding: EdgeInsets.all(15),
              height: height/14,
              width:double.infinity,
              child: Text("Description",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
          ),
          Padding(
            padding:EdgeInsets.only(left: width/30,right:width/30 ),
            child: TextField(
              maxLines: 5,
              controller: t4,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.black12,
                border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(5)
                ),
              ),
            ),
          ),
          ElevatedButton(style: ElevatedButton.styleFrom(padding: EdgeInsets.only(left: 30,right: 30,top: 10,bottom: 15),primary: Colors.black12),onPressed: () async {
            String cat_type=t.toString();
            String cat_name=t2.text;
            String mrp=t3.text;
            String cat_desc=t4.text;


//http://workfordemo.in/bunch1/insert_category.php?cat_type=vegan&cat_name=Fruits&cat_description=test&cat_qty=5
            var url = Uri.parse('https://varshil90997.000webhostapp.com/second.php?cat_f=${cat_type}&cat_name=${cat_name}&cat_mrp=${mrp}&cat_description=${cat_desc}');
            var response = await http.get(url);

            print('Response status: ${response.statusCode}');
            print('Response body : ${response.body}');
            print("${cat_type},${cat_name},${mrp},${cat_desc}");

          }, child: Text("SUBMIT")),
        ],
      ),
    );
  }
}
