import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class viewsecond extends StatefulWidget {
  const viewsecond({Key? key}) : super(key: key);

  @override
  State<viewsecond> createState() => _viewsecondState();
}

class _viewsecondState extends State<viewsecond> {
  List l=[];
  go()
  async {
      var url = Uri.parse("uri");
      var response = await http.get(url);

      print('Response status: ${response.statusCode}');
      print('Response body : ${response.body}');

      l= jsonDecode(response.body);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder(future: go(),builder: (context, snapshot){
          if(snapshot.connectionState == ConnectionState.done)
          {
            return ListView.builder(itemCount: l.length,itemBuilder: (context, index) {
              var urs=user.fromJson(l[index]) ;
              return Container(
                child: Column(
                  children: [
                    Text("${urs.name}"),
                    Text("${urs.type}"),
                    Text("${urs.adress}"),
                    Text("${urs.mobileNumber}"),

                  ],
                ),
              );
            },);
          }
          else
          {
            return Text("data");
          }
        },)

    );
  }
}
