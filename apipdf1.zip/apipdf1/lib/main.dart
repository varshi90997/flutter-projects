import 'dart:convert';


import 'package:apipdf1/second/second%20firstpage.dart';
import 'package:apipdf1/third/third%20firsdtpage.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: tfirstpage()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}
enum type{veg,nonveg,egg,vegan}
class _firstState extends State<first> {
  late type p1;
  String category="";
  var size,height,width;
  String typ="vegetarian";

  //bool p1=false;
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  TextEditingController t3=TextEditingController();
  TextEditingController t4=TextEditingController();


  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    // height = size.height;
    height=MediaQuery.of(context).size.height *1;//2=100%, 1=50%
    width = size.width;
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(10),
                  height: height/15,
                  width:double.infinity,
                  color: Colors.black54,
                  child:Center(child:  Text(" EDITE CATEGORY",style: TextStyle(color: Colors.white,fontSize: 20)),)
            ),
            
            Container(
              padding: EdgeInsets.all(15),
              height: height/15,
              width:double.infinity,
              child: Text("Name",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
            ),
            
            Padding(
              padding:EdgeInsets.only(left: width/30,right:width/30 ),
              child: TextField(
                controller: t1,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black12,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5)
                  ),
                ),
              ),
            ),
            Container(
                padding: EdgeInsets.all(15),
                height: height/14,
                width:double.infinity,
                child: Text("Type",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
            ),

            // Row(
            //   children: [
            //     Expanded(child: ListTile(
            //         leading: Radio(value: p1, groupValue: Category, onChanged: (value) {
            //             setState(() {
            //               p1=true;
            //             });
            //         },),
            //         title: Text("data",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            //       ), ),
            //     Expanded(child: ListTile(
            //       leading: Radio(value: "value", groupValue: Category, onChanged: (value) {
            //
            //       },),
            //       title: Text("data",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            //     ), ),
            //     Expanded(child: ListTile(
            //       leading: Radio(value: "value", groupValue: Category, onChanged: (value) {
            //
            //       },),
            //       title: Text("data",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            //     ), ),
            //     Expanded(child: ListTile(
            //       leading: Radio(value: "value", groupValue: Category, onChanged: (value) {
            //
            //       },),
            //       title: Text("data",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            //     ), )
            //   ],
            // ),
            Row(
              children: [
                Expanded(
                  child: RadioListTile(
                    autofocus: true,
                    title: Text("vegetarian"),
                    value: "vegetarian",
                    groupValue: typ,
                    onChanged: (value){
                      setState(() {
                          typ=value.toString();
                      });
                    },
                  ),
                ),
                Expanded(
                  child: RadioListTile(
                    title: Text("nonvegetarian"),
                    value:"nonvegetarian",
                    groupValue: typ,
                    onChanged: (value){
                      setState(() {
                        typ=value.toString();
                      });
                    },
                  ),
                ),

              ],
            ),
            Row(
              children: [
                Expanded(
                  child: RadioListTile(
                    title: Text("Eggatarial"),
                    value:"Eggatarial",
                    groupValue: typ,
                    onChanged: (value){
                      setState(() {
                        typ=value.toString();
                      });
                    },
                  ),
                ),
                Expanded(
                  child: RadioListTile(
                    title: Text("vegan"),
                    value: "vegan",
                    groupValue: typ,
                    onChanged: (value){
                      setState(() {
                        typ=value.toString();
                      });
                    },
                  ),
                ),

              ],
            ),
            Container(
                padding: EdgeInsets.all(15),
                height: height/14,
                width:double.infinity,
                child: Text("Description",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
            ),
            Padding(
              padding:EdgeInsets.only(left: width/30,right:width/30 ),
              child: TextField(
                controller: t3,
                maxLines: 5,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black12,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5)
                  ),
                ),
              ),
            ),

            Container(
                padding: EdgeInsets.all(15),
                height: height/14,
                width:double.infinity,
                child: Text("Minimum Qty",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
            ),
            Padding(
              padding:EdgeInsets.only(left: width/30,right:width/1.5 ),
              child: TextField(
                controller: t4,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black12,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5)
                  ),
                ),
              ),
            ),
            ElevatedButton(style: ElevatedButton.styleFrom(padding: EdgeInsets.only(left: 30,right: 30,top: 15,bottom: 15),primary: Colors.black12),onPressed: () async {

            String cat_type=typ;
            String cat_name=t1.text;
            String cat_description=t3.text;
            String cat_qty=t4.text;


//http://workfordemo.in/bunch1/insert_category.php?cat_type=vegan&cat_name=Fruits&cat_description=test&cat_qty=5
            var url = Uri.parse('https://varshil90997.000webhostapp.com/first.php?cat_type=${cat_type}&cat_name=${cat_name}&cat_description=${cat_description}&cat_qty=${cat_qty}');
            var response = await http.get(url);

            print('Response status: ${response.statusCode}');
            print('Response body : ${response.body}');
            print("${cat_type},${cat_name},${cat_description},${cat_qty}");

            // Map m=jsonDecode(response.body);
            // print(m['cat_type']);
            // print(m['cat_name']);
            // print(m['cat_description']);
            // print(m['cat_qty']);
          }, child: Text("insert",style: TextStyle(fontSize: 20),)),
            // ElevatedButton(onPressed: () {
            //   Navigator.push(context, MaterialPageRoute(builder: (context) {
            //
            //   },));
            // }, child: Text("view"))
          ],
        ),
      ),
    );
  }

}
