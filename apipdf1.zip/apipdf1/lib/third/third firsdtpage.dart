import 'package:apipdf1/third/viewthird.dart';
import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


class tfirstpage extends StatefulWidget {
  const tfirstpage({Key? key}) : super(key: key);

  @override
  State<tfirstpage> createState() => _tfirstpageState();
}

class _tfirstpageState extends State<tfirstpage> {
  var size,height,width;
  String t="varachha";
  String y="";
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  TextEditingController t3=TextEditingController();
  TextEditingController t4=TextEditingController();
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    // height = size.height;
    height=MediaQuery.of(context).size.height *1;//2=100%, 1=50%
    width = size.width;
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
                margin: EdgeInsets.all(10),
                height: height/15,
                width:double.infinity,
                color: Colors.black54,
                child:Center(child:  Text("ADD ADDRESS",style: TextStyle(color: Colors.white,fontSize: 20)),)
            ),
            Container(
              margin: EdgeInsets.all(height/110),
              height: height/15,

              width: double.infinity,
              decoration: BoxDecoration(color: Colors.black12,borderRadius: BorderRadius.circular(10)),
              child: DropdownButton(
                value: "$t",
                isExpanded: true,
                elevation: 16,
                icon: Icon(Icons.arrow_drop_down_sharp,size: 40,),
                borderRadius: BorderRadius.circular(10),
                items: [
                  DropdownMenuItem(child: Text("varachha"),value: "varachha",),
                  DropdownMenuItem(child: Text("yogichowk"),value: "yogichowk",),
                  DropdownMenuItem(child: Text("adajan"),value: "adajan",),
                ],
                onChanged: (value) {
                  setState(() {
                    t=value.toString();
                  });
                },),
            ),
            Container(
                padding: EdgeInsets.all(15),
                height: height/16,
                width:double.infinity,
                child: Text("ADDRESS TYPE",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold,color: Colors.black),)
            ),
            CustomRadioButton(
              elevation: 0,
              absoluteZeroSpacing: false,
              unSelectedColor: Theme.of(context).canvasColor,
              buttonLables: [
                'Student',
                'Parent',
                'Teacher',
              ],
              buttonValues: [
                "STUDENT",
                "PARENT",
                "TEACHER",
              ],
              buttonTextStyle: ButtonTextStyle(
                  selectedColor: Colors.white,
                  unSelectedColor: Colors.black,
                  textStyle: TextStyle(fontSize: 16)),
              radioButtonValue: (value) {
                print(value);
                setState(() {
                  y=value.toString();
                });
              },
              selectedColor: Theme.of(context).accentColor,
            ),

            Container(
                padding: EdgeInsets.all(15),
                height: height/14,
                width:double.infinity,
                child: Text("MOBILE NUMBER",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
            ),
            Padding(
              padding:EdgeInsets.only(left: width/30,right:width/30 ),
              child: TextField(
                controller: t3,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black12,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5)
                  ),
                ),
              ),
            ),

            Container(
                padding: EdgeInsets.all(15),
                height: height/14,
                width:double.infinity,
                child: Text("NAME",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),)
            ),
            Padding(
              padding:EdgeInsets.only(left: width/30,right:width/30 ),
              child: TextField(
                controller: t4,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black12,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5)
                  ),
                ),
              ),
            ),
            ElevatedButton(style: ElevatedButton.styleFrom(padding: EdgeInsets.only(left: 30,right: 30,top: 10,bottom: 15),primary: Colors.black12),onPressed: () async {
              String adr=t;
              String type=y;
              String mrp=t3.text;
              String name=t4.text;


//http://workfordemo.in/bunch1/insert_category.php?cat_type=vegan&cat_name=Fruits&cat_description=test&cat_qty=5
              var url = Uri.parse('https://varshil90997.000webhostapp.com/third.php?cat_adr=${adr}&cat_type=${type}&cat_mrp=${mrp}&cat_name=${name}');
              var response = await http.get(url);

              print('Response status: ${response.statusCode}');
              print('Response body : ${response.body}');
              print("${adr},${type},${mrp},${name}");

            }, child: Text("SUBMIT")),
            ElevatedButton(onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return viewthirdpage();
              },));
            }, child: Text("view"))
          ],
        ),
      ),
    );
  }
}
