class user {
  String? id;
  String? adress;
  String? type;
  String? mobileNumber;
  String? name;

  user({this.id, this.adress, this.type, this.mobileNumber, this.name});

  user.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    adress = json['adress'];
    type = json['type'];
    mobileNumber = json['mobile number'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['adress'] = this.adress;
    data['type'] = this.type;
    data['mobile number'] = this.mobileNumber;
    data['name'] = this.name;
    return data;
  }
}