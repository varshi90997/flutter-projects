import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  @override
  Widget build(BuildContext context) {

    double width=MediaQuery.of(context).size.width;
    double height=MediaQuery.of(context).size.height;
    double appbarheight=kToolbarHeight;
    double statusbarhright=MediaQuery.of(context).padding.top;
    double bottombarhright=MediaQuery.of(context).padding.bottom;

    double bodyheight=height-appbarheight-statusbarhright-bottombarhright;


    return Scaffold(
      appBar: AppBar(),
      body: Column(
         children: [
           Container(
             margin: EdgeInsets.all(10),
             height: bodyheight*0.2,
             width: width*0.5,
             color: Colors.blue,
           ),

           Container(
             height: bodyheight*0.8-20,
             width: width*0.5,
             color:Colors.red,
           ),
         ],
      ),

    );
  }
}
