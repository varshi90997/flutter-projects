package com.example.note_applica;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
