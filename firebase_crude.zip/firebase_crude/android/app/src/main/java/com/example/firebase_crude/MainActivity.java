package com.example.firebase_crude;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
