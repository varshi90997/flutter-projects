import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:second/first.dart';

void main(){
  runApp(MaterialApp(home: first(null),));
}