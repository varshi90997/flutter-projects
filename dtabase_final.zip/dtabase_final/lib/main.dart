import 'package:dtabase_final/show_data.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main()
{
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  Database ?database;
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();

  @override
  void initState() {
    super.initState();
    go();
  }
  go ()
  async {
    // Get a location using getDatabasesPath
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'demo.db');


// open the database
    database = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(
              'CREATE TABLE Test (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact TEXT)');
        });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("database")),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.all(10),
            height: 100,
            width: double.infinity,
            child: TextField(controller: t1,decoration: InputDecoration(hintText: "name",fillColor: Colors.blueAccent, border: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.circular(50)
            ),)),
          ),
          Container(
            height: 100,
            width: double.infinity,
            child: TextField(controller: t2,decoration: InputDecoration(hintText: "contact",fillColor: Colors.blueAccent, border: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.circular(50)
            ),)),
          ),
          ElevatedButton(onPressed: () async {
                    String first=t1.text;
                    String second=t2.text;

                    String qry="insert into Test values(null,'$first','$second')";
                    print(qry);

                    if(first!=""&&second!="")
                      {
                        int r_id;
                        r_id=await database!.rawInsert(qry);
                        print(" row_id= $r_id");
                      }
                    
                    t1.text="";
                    t2.text="";
          }, child: Text("submit",style: TextStyle(fontSize: 20),)),
          ElevatedButton(onPressed: () {
             Navigator.push(context , MaterialPageRoute(builder: (context) {
              return sec(database!);
            },));
          }, child: Text("SHOW DATA",style: TextStyle(fontSize: 20),))
        ],
      ),
    );
  }
}
