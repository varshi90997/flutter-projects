import 'package:dtabase_final/show_data.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

class th extends StatefulWidget {
 int id;
 String name;
 String contact;
 Database database;

 th(this.id,this.name,this.contact,this.database);


  @override
  State<th> createState() => _thState();
}

class _thState extends State<th> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();

  @override
  void initState() {
    super.initState();
    t1.text=widget.name ;
    t2.text=widget.contact ;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("UPDATE"),automaticallyImplyLeading: false),
      body: Column(children: [

        TextField(controller: t1,),
        TextField(controller: t2,),


        ElevatedButton(onPressed: () async {
          String first=t1.text;
          String second=t2.text;

          String q="update Test set name='${first}',contact='${second}' where id=${widget.id}";
          int t=await widget.database.rawUpdate(q);

          if(t==1)
            {
              print("data updated");
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                return sec(widget.database);
              },));
            }
          else
            {
              print("data not updated");
            }
        }, child: Text("UPDATE"))
      ]),
    );
  }
}
