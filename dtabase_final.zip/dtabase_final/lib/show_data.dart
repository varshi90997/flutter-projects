import 'package:dtabase_final/edit%20page.dart';
import 'package:flutter/material.dart';
import 'package:sqflite_common/sqlite_api.dart';

class sec extends StatefulWidget {


  Database database;
  sec(this.database);


  @override
  State<sec> createState() => _secState();
}

class _secState extends State<sec> {
  List name=[];
  List contact=[];
  List id=[];
  get_data()
  async {
    String qry="select * from Test";
    List<Map> list=[];
    list=await widget.database.rawQuery(qry);
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("show data")),
      body: FutureBuilder(future: get_data(),builder: (context, snapshot) {
        name.clear();
        contact.clear();
        id.clear();
        if(snapshot.connectionState==ConnectionState.done)
          {
           if(snapshot.hasData)
             {
               List<Map>? st=[];
               st=snapshot.data as List<Map>?;

               st!.forEach((element) {
                 name.add(element['name']);
                 contact.add(element['contact']);
                 id.add(element['id']);
               });
             }

           return ListView.builder(itemCount: name.length,itemBuilder: (context, index) {

             return ListTile(
               title: Text(name[index]),
               subtitle: Text(contact[index]),
               trailing: Column(
                 children: [
                   Expanded(child: IconButton(onPressed: () async {

                                String q="delete from Test where id =${id[index]}";
                                int t= await widget.database.rawDelete(q);

                                print(t);
                                if(t==1)
                                  {
                                    setState(() {

                                    });
                                  }
                                else
                                  {
                                    print("not deleted");
                                  }
                   }, icon: Icon(Icons.delete))),
                   Expanded(child: IconButton(onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return th(id[index],name[index],contact[index],widget.database);
                          },));
                   }, icon: Icon(Icons.edit)))
                 ],
               ),
             );
           },);
          }
        else
          {
            return Center(child: CircularProgressIndicator(),);
          }
      },),
    );
  }
}
