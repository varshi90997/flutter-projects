import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  String str="";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }
  getdata()
  async {             //link che oowebhost mathi je kai domain and host banavyu teni
    var url = Uri.http('varshil90997.000webhostapp.com', 'img/images.jpg');
    var response = await http.get(url);
    str=response.body;

    setState(() {
      //application farithi run karva mate
    });

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body:Container(
        height: 200,
        width: 200,
        decoration: BoxDecoration(image: DecorationImage(image: AssetImage("$str"))),
      )
    );
  }
}
