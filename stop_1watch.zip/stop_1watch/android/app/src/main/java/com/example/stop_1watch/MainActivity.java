package com.example.stop_1watch;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
