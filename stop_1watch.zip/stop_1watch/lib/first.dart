import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  String only="";
  bool Start=false;
  int sec=0;
  int min=0;
  int hr=0;
  String store="";
  StringBuffer sd=StringBuffer();


  @override
  void initState() {
    super.initState();
    get();
  }
  Stream<String> get()
  async*
  {
    while(true)
    {
      await Future.delayed(Duration(seconds: 1));
      String time="${hr} : ${min} : ${sec}";
      if(Start)
      {
        sec=sec+1;
      }
      if(sec>=60)
        {
          sec=0;
          min=min+1;
        }
      if(min>=60)
      {
        min=0;
        hr=hr+1;
      }
      yield time;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Row(
            children: [
              SizedBox(height: 100,),
            ],
          ),
          Row(
            children: [
              Expanded(child:StreamBuilder(stream: get(),builder: (context, snapshot) {
                if(snapshot.connectionState==ConnectionState.done)
                {
                  return Center(child: CircularProgressIndicator(),);
                }
                else
                {
                  return Center(child: Container(alignment: Alignment.center,child: Text((Start==true)?"time: ${snapshot.data}":"${store}",style: TextStyle(fontSize: 20)),));
                }
              },),),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
             ElevatedButton(onPressed: () {
               Start=true;
               setState(() {
                 store="";
               });
             }, child: Text("start")),

            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(onPressed: () {

                setState(() {
                  Start=false;
                  sec=sec-1;
                  store= "${hr.toString()} : ${min.toString()} : ${sec.toString()}";
                  sec=0;
                  min=0;
                  hr=0;
                });
              }, child: Text("stop")),
            ],
          ),
              Center(
                child: Container(
                  child: Text("${store}"),
                ),
              )

        ],
      ),

    );
  }

}
