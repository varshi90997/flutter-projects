import 'package:flutter/material.dart';
import 'package:stop_1watch/first.dart';

void main()
{
  runApp(MaterialApp(home: first()));
}
