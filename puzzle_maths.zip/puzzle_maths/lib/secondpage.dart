
import 'package:flutter/material.dart';

class secondpage extends StatefulWidget {
  const secondpage({Key? key}) : super(key: key);

  @override
  State<secondpage> createState() => _secondpageState();
}

class _secondpageState extends State<secondpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child:Container(
        decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/background.jpg"),fit: BoxFit.cover)),
          child: Column(
            children: [
              Expanded(
                child: Container(
                  height: 50,
                  alignment: Alignment.center,
                  child: Text("Math Puzzles",style: TextStyle(fontSize: 35,color: Colors.indigo),),
                ),
              ),
               Container(height: 600, width: double.infinity,
                 child: GridView.builder(itemCount: 20,itemBuilder: (context,index){
                   return InkWell(
                     onTap: (){

                     },
                     child: Container(
                       margin: EdgeInsets.all(10),
                       decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/lock.png"),fit: BoxFit.cover)
                       ),
                     ),
                   );
                 },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4)),
               ),
                  Container(
                    height: 100,
                    width: 100,
                    alignment: Alignment.bottomLeft,
                    decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/next.png"),fit: BoxFit.cover)),
                  ),
            ],
          ),
        ),
      ),
    );
  }
}
