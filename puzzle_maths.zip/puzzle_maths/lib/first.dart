import 'package:flutter/material.dart';
import 'package:puzzle_maths/model.dart';
import 'package:puzzle_maths/second.dart';
import 'package:puzzle_maths/secondpage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  String font="p1";
  List<String> game_status=[];
  SharedPreferences ?pref;
  int level=0;


  @override
  void initState() {
  super.initState();
  game_status=List.filled(models.ans.length, "no");
  go();
  }
go()
async {
  pref= await SharedPreferences.getInstance();
  level=pref!.getInt("level_number")?? 0;

  for(int i=0;i<game_status.length;i++)
    {
      game_status[i]=pref!.getString("level_status$i")?? "no";
    }
  print(game_status);
  print("pref=${pref!.getInt("level_number")}");
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/background.jpg"),fit: BoxFit.cover)),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 100,
                      alignment: Alignment.bottomCenter,
                      // color: Colors.deepOrange,
                      child: Text("MATH PUZZLES",style: TextStyle(fontSize: 29,color: Colors.black)),
                    ),
                  ),
                  SizedBox(height: 30),
                ],
              ),
              Container(
                height:450,
                margin: EdgeInsets.all(20),
                width: double.infinity,alignment: Alignment.center,
                // color: Colors.indigoAccent,
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/blackboard_main_menu.png"),fit: BoxFit.fill)),
                child: Column(
                        children: [
                          SizedBox(height: 150,),
                          // GestureDetector(
                          //   onTap: () {
                          //     setState(() {
                          //       ver1=false;
                          //     });
                          //   },
                          //   onTapCancel: () {
                          //     setState(() {
                          //       ver1=true;
                          //     });
                          //   },
                          //   onTapDown: (details) {
                          //     setState(() {
                          //       ver1=false;
                          //       print(ver1);
                          //     });
                          //   },
                          //   child:  InkWell(
                          //     onTap: () {
                          //
                          //       Navigator.push(context, MaterialPageRoute(builder: (context) {
                          //         return second(0);
                          //       },));
                          //     },
                          //       child: Container(
                          //         height: 35,
                          //         alignment: Alignment.center,
                          //         width: 120,
                          //         decoration: BoxDecoration(border: Border.all(color: (ver1=false)?Colors.blue:Colors.red)),
                          //         child:Text("CONTINUE",style: TextStyle(fontFamily:font,fontSize: 20,color: Colors.white),)),
                          //
                          //       ),
                          //     ),
                             Container(
                               alignment: Alignment.center,
                               child: ElevatedButton(style: ElevatedButton.styleFrom(primary: Colors.transparent,),onPressed: () {

                                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                                    return second(level);
                                  },));

                                }, child: Text("CONTINUE",style: TextStyle(fontFamily:font,fontSize: 20),)),
                             ),


                          SizedBox(height: 20),

                          Container(
                            alignment: Alignment.center,
                            child: ElevatedButton(style: ElevatedButton.styleFrom(primary: Colors.black),onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) {
                                return secondpage();
                              },));
                            }, child: Text("PUZZLES",style: TextStyle(fontFamily:font,fontSize: 20),)),
                          ),
                          SizedBox(height: 20),
                          Container(
                            alignment: Alignment.center,
                            child: ElevatedButton(  style: ElevatedButton.styleFrom(primary: Colors.transparent),onPressed: () {

                            }, child: Text("BUY PRO",style: TextStyle(fontFamily:font,fontSize: 20),)),
                          ),
                        ],
                ),
              ),
              Row(
                children: [
                  Column(children: [
                    Container(
                      height: 20,
                      width: 100,
                     alignment: Alignment.center,
                      child: Text("AD",style: TextStyle(color: Colors.indigo)),
                    ),
                    Container(
                      height: 80,
                     width: 100,
                    margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/ltlicon.png"),fit: BoxFit.fill)),
                    ),
                  ]),

                  SizedBox(width: 120,),
                  Column(children: [
                      Row(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {

                            },
                            child: Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration( gradient: LinearGradient(colors: [Colors.black26,Colors.black26,Colors.white,Colors.black26]),
                                borderRadius: BorderRadius.circular(10),),
                              padding: EdgeInsets.all(9),
                              child: Container(
                                // alignment: Alignment.center,
                                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/shareus.png")),

                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 10,),
                          InkWell(
                            onTap: () {

                            },
                            child: Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration( gradient: LinearGradient(colors: [Colors.black26,Colors.black26,Colors.white,Colors.black26]),
                                borderRadius: BorderRadius.circular(10),),
                              padding: EdgeInsets.all(9),
                              child: Container(
                                // alignment: Alignment.center,
                                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/emailus.png")),

                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        Container(
                          height: 30,
                          width: 100,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(border: Border.all(width: 1)),
                          child: Text("privacy policy"),
                        )
                      ],
                    )

                  ]),

                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
