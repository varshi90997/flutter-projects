import 'package:flutter/material.dart';
import 'package:puzzle_maths/forthpage.dart';
import 'package:puzzle_maths/model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class second extends StatefulWidget {
  int level;
  second(this.level);



  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  String num = "";
  int cr_ans=0;
  int level=0;
SharedPreferences ?pref;

  @override
  void initState() {
    super.initState();
    level=widget.level;
    get();
  }
  get()
  async {
    pref= await SharedPreferences.getInstance();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("img/gameplaybackground.jpg"),
                        fit: BoxFit.fill)),
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        InkWell(onTap: () {
                          pref!.setString("level_status $level", "skip");
                          level++;
                          pref!.setInt("level_number",level);
                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                            return second(level);
                          },));
                        },
                          child: Container(
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage("img/skip.png"),
                                    fit: BoxFit.fill)),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                            child: Container(
                          alignment: Alignment.center,
                          height: 50,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage("img/level_board.png"),
                                  fit: BoxFit.fill)),
                          child: Text("Level ${level+1}",
                              style: TextStyle(
                                  fontSize: 30, fontWeight: FontWeight.bold)),
                        )),
                        SizedBox(width: 10),
                        Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage("img/hint.png"),
                                  fit: BoxFit.fill)),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            height: 320,
                            margin: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage("img/${models.images[level]}"),
                                    fit: BoxFit.fill)),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: 140,
              width: double.infinity,
              child: Column(
                children: [
                  Container(
                    height: 70,
                    width: double.infinity,
                    color: Colors.black,
                    child: Row(children: [
                      Expanded(
                          child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(color: Colors.black),
                            borderRadius: BorderRadius.circular(
                              10,
                            )),
                        child: Text("${num}",
                            style: TextStyle(color: Colors.black)),
                      )),
                      SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () {
                        setState(() {
                          if(num!="")
                          {
                            num=num.substring(0,num.length-1);
                          }
                        });
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage("img/delete.png"),
                                  fit: BoxFit.fill)),
                        ),
                      ),
                      InkWell(
                         onTap: () {
                           setState(() {
                             cr_ans=int.parse(num);
                             if(models.ans[level]==cr_ans)
                             {
                               pref!.setString("level_status$level", "yes");
                               level++;
                               pref!.setInt("level_number", level);
                               Navigator.push(context,
                                   MaterialPageRoute(
                                     builder: (context) {
                                       return forthpage(level);
                                     },
                                   ));
                             }
                           });

                         },
                        child: Container(
                          height: 50,
                          width: 80,
                          child:
                               Text(
                                "SUBMIT",
                                style: TextStyle(fontSize: 15,color: Colors.white),
                              ),
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    height: 70,
                    width: double.infinity,
                    color: Colors.black,
                    child: Row(children: [
                      button("1"),
                      button("2"),
                      button("3"),
                      button("4"),
                      button("5"),
                      button("6"),
                      button("7"),
                      button("8"),
                      button("9"),
                      button("0"),
                    ]),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  @override


  button(String i) {
    return Expanded(
      child: Container(
        alignment: Alignment.centerLeft,
        height: 40,
        width: 35,
        margin: EdgeInsets.all(1),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: Colors.white,
            )),
        child: ElevatedButton(
            style: ElevatedButton.styleFrom(primary: Colors.white60),
            onPressed: () {
              setState(() {
                num = num + i;
              });
            },
            child: Text(
              "${i}",
              style: TextStyle(color: Colors.white, fontSize: 20),
            )),
      ),
    );
  }
}
