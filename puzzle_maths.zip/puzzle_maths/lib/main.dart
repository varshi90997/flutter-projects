import 'package:flutter/material.dart';
import 'package:puzzle_maths/first.dart';

void main()
{
  runApp(MaterialApp(home: first()));
}