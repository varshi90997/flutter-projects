import 'package:flutter/material.dart';
import 'package:puzzle_maths/first.dart';
import 'package:puzzle_maths/second.dart';



class forthpage extends StatefulWidget {
  int level;
  forthpage(this.level);


  @override
  State<forthpage> createState() => _forthpageState();
}

class _forthpageState extends State<forthpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child:Container(
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/background.jpg"),fit: BoxFit.cover)),
        child: Column(
          children: [
            SizedBox(height: 20,),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    child: Text("puzzle ${widget.level} complete",style: TextStyle(fontSize: 25,color: Colors.indigo,fontWeight: FontWeight.bold),),
                  ),
                )
              ],
            ),
            SizedBox(height: 15,),
                Container(
                  height: 250,
                  width: 200,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/trophy.png"),fit: BoxFit.fill)),
                ),
            SizedBox(height: 10,),
            Container(
              height: 50,
              width: 170,
              decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black26,Colors.black26,Colors.white,Colors.black26],),
                borderRadius: BorderRadius.circular(15),),
              child: ElevatedButton(style: ElevatedButton.styleFrom(primary: Colors.grey),onPressed: () {
                Navigator.push(context,MaterialPageRoute(builder: (context) {
                  return second(widget.level);
                },));
              }, child:Text("CONTINUE",style: TextStyle(fontSize: 25,color: Colors.black),)),
            ),
            SizedBox(height: 10,),
            Container(
              height: 50,
              width: 170,
              child: ElevatedButton(style: ElevatedButton.styleFrom(primary: Colors.grey),onPressed: () {
                Navigator.push(context,MaterialPageRoute(builder: (context) {
                  return first();
                },));
              }, child:Text("PUZZLES",style: TextStyle(fontSize: 25,color: Colors.black),)),
            ),
            SizedBox(height: 10,),
            Container(
              height: 50,
              width: 170,
              child: ElevatedButton(style: ElevatedButton.styleFrom(primary: Colors.grey),onPressed: () {
                Navigator.push(context,MaterialPageRoute(builder: (context) {
                  return first();
                },));
              }, child:Text("BUY PRO",style: TextStyle(fontSize: 25,color: Colors.black),)),
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    child: Text("SHARE THIS PUZZLE",style: TextStyle(fontSize: 25,color: Colors.indigo,fontWeight: FontWeight.bold),),
                  ),
                )
              ],
            ),
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black26,Colors.black26,Colors.white,Colors.black26],),
                borderRadius: BorderRadius.circular(15),),
              padding: EdgeInsets.all(5),
              child: Container(
                decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/shareus.png"),fit: BoxFit.fill)),
              ),
            ),
          ],
        ),
          ),
      ),
    );
  }
}
