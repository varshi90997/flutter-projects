class models
{
  static List<int> ans=[10,20,30,40,50,60,70,80,90,100];
  static List<String> images=["p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png","p10.png"];
}