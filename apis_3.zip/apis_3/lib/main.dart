import 'dart:convert';


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          TextField(controller: t1,),
          TextField(controller: t2,),
          ElevatedButton(onPressed: () async {

            String name,job;
            name=t1.text;
            job=t2.text;

            var url = Uri.https('reqres.in', 'api/users');
            var response = await http.post(url,body: {'name':name , 'job':job});

            print('Response status: ${response.statusCode}');
            print('Response body : ${response.body}');

            Map m=jsonDecode(response.body);
            print(m['name']);
            print(m['job']);
            print(m['id']);
            print(m['createdAt']);
          }, child: Text("insert"))
        ],
      ),
    );
  }

}
