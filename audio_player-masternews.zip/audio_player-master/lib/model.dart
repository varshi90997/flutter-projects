class model
{
  static List image=["pexels-elijah-o'donnell-8038906.jpg","pexels-everson-mayer-1481312.jpg","pexels-loong-ken-1564668.jpg","f1.jpg","pexels-pixabay-416831.jpg","pexels-elijah-o'donnell-8038906.jpg","f1.jpg","f1.jpg","f1.jpg","f1.jpg","f1.jpg","f1.jpg"];
}