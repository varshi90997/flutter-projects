import 'package:audio_player/modalsec.dart';
import 'package:audio_player/model.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:getwidget/components/button/gf_button.dart';
import 'package:getwidget/components/button/gf_icon_button.dart';
import 'package:on_audio_query_platform_interface/details/on_audio_query_helper.dart';
import 'package:provider/provider.dart';



class seconds extends StatelessWidget {
  List<SongModel> songs;

  int index;
  seconds(this.songs,this.index);

  model m=model();

  @override
  Widget build(BuildContext context) {
    logic l=Provider.of(context);
    l.details();
    return  Scaffold(
        body: Container(
          margin: EdgeInsets.all(4),
          decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/${model.image[index]}"),fit: BoxFit.cover)),
          child: Column(
            children: [
              Expanded(
                child: PageView.builder(
                  controller: l.pc,
                  itemCount: songs.length,
                  onPageChanged: (value) {
                    print(value);
                    index=value;

                  },
                  itemBuilder: (context, index) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Center(child: Container(alignment: Alignment.center,child: Text("${songs[index].title}",style: TextStyle(fontSize: 20,color: Colors.white)),height: 50,width: 300,color: Colors.transparent,)),
                          SizedBox(height: 5,),
                          Center(child: Container(alignment: Alignment.center,child: Text("${songs[index].duration}",style: TextStyle(fontSize: 20,color: Colors.white)),height: 50,width: 300,color: Colors.transparent)),
                          SizedBox(height: 200,),
                        ],
                      ),
                    );
                  },),
              ),
              Slider(
                value: l.current_time,
                min: 0,
                max: songs[index].duration!.toDouble(),
                onChanged: (value) async {
                  await l.player.seek(Duration(milliseconds: value.toInt()));//5-seek nma ena bydefault function thi je initsate nathi current value ave te pramane slider ne hlave che
                },),
              Container(
                padding: EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration( color: Colors.white54,borderRadius: BorderRadius.circular(100)),
                margin: EdgeInsets.only(left: 10,right: 10,bottom: 20,top: 20),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    GFIconButton(
                      onPressed: (){
                        if(index>0)
                        {
                          l.pc.jumpToPage(index);
                          index--;
                        }
                        else
                        {
                         index=songs.length-1;
                        }

                      },
                      color: Colors.transparent,
                      icon: Icon(Icons.keyboard_arrow_left,size: 50,color: Colors.white,),
                      alignment: Alignment.center,

                    ),
                    GFIconButton(
                      onPressed: () async {
                        if(l.play)//1-jo player false hoy to
                            {
                          await l.player.pause();
                        }
                        else
                        {
                          String path=songs[index].data;//2-path kadhyo device no
                          await l.player.play(DeviceFileSource(path));//3-device na songplay karva mate default ave che
                        }
                        l.play=!l.play;//true ni false and false ni true karvani value

                      },
                      color: Colors.transparent,
                      icon: l.play?Icon(Icons.pause,size: 50,color: Colors.white,):Icon(Icons.play_circle,size: 50,color: Colors.white),
                      alignment: Alignment.center,
                    ),
                    GFIconButton(
                      onPressed: (){
                        if(index<songs.length-1)
                        {
                          l.pc.jumpToPage(index);
                          index++;
                        }
                        else
                        {
                          index=0;
                        }
                      },
                      color: Colors.transparent,
                      icon: Icon(Icons.keyboard_arrow_right,size: 50,color: Colors.white),
                      alignment: Alignment.center,
                    ),
                  ],
                ),
              )
            ],
          ),
        )
    );
  }
}

