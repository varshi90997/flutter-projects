import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';


class logic extends ChangeNotifier
{

  PageController pc = PageController();


  Future<List<SongModel>> someName() async {

    OnAudioQuery _audioQuery = OnAudioQuery();

    List<SongModel> something = await _audioQuery.querySongs();
    return something;
  }


  Color iconcolor = Colors.black;
  bool iconbool = true;
  bool iconchang = true;
  final player = AudioPlayer();
  bool play=false;
  double current_time=0;
  notifyListeners();
  void details() {
    // pc = PageController(initialPage: index);
    // print(songs[index]);
    player.onPositionChanged.listen((Duration p) {
      print('Current position: $p');

      current_time = p.inMilliseconds.toDouble(); //4-music ma je currentvagtu hoy aeni  milisecond avi jase
      notifyListeners();
    });
  }
}