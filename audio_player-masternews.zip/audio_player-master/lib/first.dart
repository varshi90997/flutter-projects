import 'package:audio_player/modalsec.dart';
import 'package:audio_player/second.dart';
import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:audio_player/model.dart';
import 'package:provider/provider.dart';
import 'package:provider/provider.dart';




class pro extends StatelessWidget {

  // Future<List<SongModel>> someName() async {
  //
  //   OnAudioQuery _audioQuery = OnAudioQuery();
  //
  //   List<SongModel> something = await _audioQuery.querySongs();
  //
  //   return something;
  // }
  @override
  Widget build(BuildContext context) {

    logic l=Provider.of(context);

    String printDuration(Duration duration) {//1-milisecond ne second ma convert karva mate stackoverflow mayni copy past karyu akhu functiopn
      String twoDigits(int n) {
        if (n >= 10) return "$n";
        return "0$n";
      }

      String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
      String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
      if (duration.inHours > 0)
        return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
      else
        return "$twoDigitMinutes:$twoDigitSeconds";
    }
    return Scaffold(
      appBar: AppBar(title: Text("Audio List"),),
      body: Container(
        decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/bac.jpg"),fit: BoxFit.cover)),
        child: FutureBuilder(
          future: l.someName(),
          builder: (context, snapshot) {

            if(snapshot.connectionState==ConnectionState.done){
              List<SongModel> songs = snapshot.data as List<SongModel>;
              return ListView.builder(itemCount: songs.length,itemBuilder: (context, index) {
                SongModel s = songs[index];
                return Card(
                  color: Colors.white54,
                  child: ListTile(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) {
                        return ChangeNotifierProvider(create: (context) => logic(),child: seconds(songs, index),);
                      },));
                    },
                    leading: Container(height:50,width:50,decoration: BoxDecoration(shape: BoxShape.circle,image: DecorationImage(image: AssetImage("img/${model.image[index]}"),fit: BoxFit.cover)),),
                    title: Text("${s.title}",style: TextStyle(color: Colors.white)),
                    subtitle: Text(printDuration(Duration(milliseconds: s.duration!.toInt())),style: TextStyle(color: Colors.white)),
                  ),
                );
              },);
            }
            else{
              return Center(child: CircularProgressIndicator(),);
            }
          },),
      ),
    );
  }
}
