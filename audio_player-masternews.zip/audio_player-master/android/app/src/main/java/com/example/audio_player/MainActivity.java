package com.example.audio_player;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
