import 'dart:convert';


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get_api2/user.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
    user? s;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    go();
  }
  go()
  async {

    var url = Uri.http('reqres.in', 'api/users?page=2');
    var response = await http.get(url);

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    Map<String, dynamic> m= jsonDecode(response.body);
    print(m['data']);
    s=user.fromJson(m);
    print(s);

    setState(() {

    });

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          Text("${s!.page}"),
          Text("${s!.perPage}"),
          Text("${s!.total}"),
          Text("${s!.totalPages}"),

          ListView.builder(itemCount: s!.data!.length,itemBuilder: (context, index) {

            return ListTile(
              title: Text("${s!.data![index].name}"),
              subtitle: Text("${s!.data![index].color}"),
              leading: Text("${s!.data![index].id}"),
            );
          },
           shrinkWrap: true,
          )
        ],
      ),
    );
  }

}
