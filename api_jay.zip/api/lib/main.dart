import 'dart:convert';

import 'package:api/second.dart';
import 'package:api/third.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MaterialApp(
    home: first(),
  ));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  Map? m;

  get() async {
    var url = Uri.parse('https://dummyjson.com/products');
    var response = await http.get(url);
    print('Response status: ${response.statusCode}');
    m = jsonDecode(response.body);
    return m;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return ListView.builder(
              itemCount: 30,
              itemBuilder: (context, index) {
                List<dynamic> x = m!['products'] as List<dynamic>;
                List<dynamic> img = x[index]['images'];
                return ExpansionTile(title: Text("${x[index]['title']}"), children: [
                  Row(
                    children: [
                      Container(
                        height: 100,
                        width: 350,
                        child: ListView.builder(scrollDirection: Axis.horizontal,itemCount: img.length,itemBuilder: (context, index) {
                          return Container(
                            height: 60,
                            width: 70,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "${img[index]}"))),
                          );

                        },),
                      ),
                    ],
                  ),
                ]);
              },
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
