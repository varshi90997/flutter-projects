import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class third extends StatefulWidget {
  const third({Key? key}) : super(key: key);

  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {
  Map? m;


  get1() async {
    var url = Uri.parse('https://dummyjson.com/carts');
    var response = await http.get(url);
    print('Response status: ${response.statusCode}');
    m = jsonDecode(response.body);
    print(m);
    return m;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("second page"),
      ),
      body: FutureBuilder(future: get1(),builder: (context, snapshot) {
        if(snapshot.connectionState==ConnectionState.done){
          return ListView.builder(itemCount:  20,itemBuilder: (context, index) {
            List<dynamic> l1 = m!['carts'] as List<dynamic>;
            // print("l = ${l2[index]}");
            return ExpansionTile(title: Text("${l1[index]['id']}"), children: [
              Column(
                children: [
                  Container(
                    height: 100,
                    width: 350,
                    child: ListView.builder(itemCount: 5,itemBuilder: (context, index) {
                      List<dynamic> l2 = l1[index]['products'] as List<dynamic>;
                      return Container(
                        height: 60,
                        width: 70,
                        child: Text("${l2[index]['title']}"),
                      );

                    },),
                  ),
                ],
              ),
            ]);
          },);
        }
        else
        {
          return Center(child: CircularProgressIndicator(),);
        }
      },),
    );
  }
}
