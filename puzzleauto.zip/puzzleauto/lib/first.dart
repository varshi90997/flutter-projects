import 'dart:io';
import 'dart:typed_data';

import 'package:external_path/external_path.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as imglib;


class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  List<Image> splitImage(List<int> input) {
    // convert image to image from image package
    imglib.Image? image = imglib.decodeImage(input);

    int x = 0, y = 0;
    int width = (image!.width / 3).round();
    int height = (image!.height / 3).round();

    // split image to parts
    List<imglib.Image> parts = <imglib.Image>[];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        parts.add(imglib.copyCrop(image, x, y, width, height));
        x += width;
      }
      x = 0;
      y += height;
    }

    // convert image from image package to Image Widget to display
    List<Image> output = <Image>[];
    for (var img in parts) {
      output.add(Image.memory(Uint8List.fromList(imglib.encodeJpg(img))));
    }

    return output;
  }

  Future<File> getImageFileFromAssets(String path) async {
    final byteData = await rootBundle.load('$path');

    var directory = await ExternalPath.getExternalStoragePublicDirectory(ExternalPath.DIRECTORY_DOWNLOADS)+"/myfolder";
    print(path);
    Directory d =Directory(directory);
    if(await d.exists())
    {
      print("file is alredy exits ");
    }// /storage/emulated/0/Download
    else
    {
      d.create();
      print("create succesfully ");
      print(d.path);
    }

    final file = File('${d.path}/first.jpg');
    await file.writeAsBytes(byteData.buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));

    return file;
  }

  List<Image> imglist=[];
  createimage()
  async {
    File f = await getImageFileFromAssets('assets/first.jpg');

    List<int> intimglist=await f.readAsBytes();

    imglist=await splitImage(intimglist);
    imglist.shuffle();
    print(f.path);
    setState(() {

    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    createimage();
  }
  go()
  async {
      var path = await ExternalPath.getExternalStoragePublicDirectory(ExternalPath.DIRECTORY_DOWNLOADS)+"/puzzleapp";
      print(path);
      Directory directory =Directory(path);
      if(await directory.exists())
        {
          print("file is alredy exits ");
        }// /storage/emulated/0/Download
      else
        {
          directory.create();
          print("create succesfully ");
          print(directory.path);
        }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: GridView.builder( itemBuilder: (context, index) {
        return Container(
          child: imglist[index],
        );
      },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3,crossAxisSpacing: 10,mainAxisSpacing: 10),itemCount: imglist.length,),
    );
  }
}
