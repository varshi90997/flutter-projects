import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main()
{
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  Database ?database;
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();


  @override
  void initState() {
    super.initState();
    go();
  }
  go()
  async {
    // Get a location using getDatabasesPath
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'demo.db');


// open the database
   database = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(
              'CREATE TABLE Test (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact TEXT)');
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("data")),
      body: Column(
        children: [
          TextField(controller: t1,decoration: InputDecoration(hintText: "name"),),
          TextField(controller: t2,decoration: InputDecoration(hintText: "contact"),),
          ElevatedButton(onPressed:() async {
                 String first=t1.text;
                 String second=t2.text;

                 String qry="insert into Test values(null ,'$first', '$second')";
                 print(qry);

                 int id1;
                 id1= await database!.rawInsert(qry);
                 print(id1);

                 t1.text="";
                 t2.text="";
          } , child: Text("submit")),
        ],
      ),
    );
  }
}
