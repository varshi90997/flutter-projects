package com.example.firstdemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
