import 'dart:convert';

import 'package:firstdemo/model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


void main()
{
  runApp(MaterialApp(
    home: demo(),
  ));
}
class demo extends StatefulWidget {
  const demo({Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {
  model? m;
  List<Products> demo = [];
  @override
  void initState() {
    // TODO: implement initState
    getdata();
  }
 Future<void> getdata()
  async {

    var url = Uri.parse('https://dummyjson.com/products');
    var response = await http.get(url);


    final responsebody = jsonDecode(response.body);
    print(response.statusCode);
    if(response.statusCode ==200)
      {
        m = model.fromJson(responsebody);

        demo = m!.products!;
        print(demo);

      }

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: ListView.builder(itemCount: demo.length,itemBuilder: (context, index) {
        return ListTile(
          title: Text("${demo[index].title}"),
          leading: Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              image: DecorationImage(fit: BoxFit.cover,image: NetworkImage('${demo[index].thumbnail.toString()}'))
            ),
          ),
        );
      },)),
    );
  }
}
