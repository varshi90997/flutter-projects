

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:shayari/practice.dart';
import 'package:shayari/shayari.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shayari/splash.dart';

void main() {
  runApp(MaterialApp(
    // debugShowCheckedModeBanner: false,
    home: splash(),
    theme: ThemeData(
      // backgroundColor: Color(0xffb90606),
      primarySwatch: Colors.teal,
    ),
  ));
}

