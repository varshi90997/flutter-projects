import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: first(),));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  var datas;
  Future<void> getuserapi()async
  {
    var url = Uri.parse('https://cleaner-sweep.tk/mobile/services/getBanner');
    var response = await http.get(url);


    if(response.statusCode ==200)
    {
      print(response.body.toString());
      datas=jsonDecode(response.body.toString());
    }
    else
    {
      // print(response.body.toString());
      // datas=jsonDecode(response.body.toString());
      Center(child: CircularProgressIndicator(),);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Complex api")),
      body: Column(
        children: [
          Expanded(child: FutureBuilder(future: getuserapi(),builder: (context, snapshot) {
            if(snapshot.connectionState==ConnectionState.waiting)
            {
              return Text("Loading");
            }
            else
            {
              print(datas);
              return ListView.builder(itemCount:1,itemBuilder: (context, index) {
                return Card(

                  child: Column(
                    children: [
                      Reusablerow(title: "issuccess", value: datas['issuccess'].toString()),
                      Reusablerow(title: "acknowledgement", value: datas['data']['acknowledgement'].toString()),
                      Reusablerow(title: "message", value: datas['message'].toString()),
                      // Reusablerow(title: 'username', value: data[index]['username'].toString()),
                    ],
                  ),);
              },);
            }
          },))
        ],
      ),
    );
  }
}
class Reusablerow extends StatelessWidget {
  String title,value;

  Reusablerow({Key? key ,required this.title,required this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [

        Text(title),
        Text(value),
      ],
    );
  }
}

