import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:img_database/second.dart';
import 'package:sqflite_common/sqlite_api.dart';

class third extends StatefulWidget {
  int id;
  String name, contact, image;
  Database database;
  third(this.id,this.name,this.contact,this.image,this.database);

  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  ImagePicker _picker = ImagePicker();
  XFile? image;
  bool t = false;

  @override
  void initState() {
    super.initState();
    t1.text=widget.name;
    t2.text=widget.contact;
    //image=widget.image as XFile?;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 25,
            ),
            TextField(
              controller: t1,
              decoration: InputDecoration(hintText: "Enter Name"),
            ),
            SizedBox(
              height: 25,
            ),
            TextField(
              controller: t2,
              decoration: InputDecoration(hintText: "Enter Contact"),
            ),
            SizedBox(
              height: 25,
            ),
            TextButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text("Select Camera Or Gallery"),
                        actions: [
                          TextButton(
                              onPressed: () async {
                                image = await _picker.pickImage(
                                    source: ImageSource.camera);
                                setState(() {
                                  t = true;
                                });
                                Navigator.pop(context);
                              },
                              child: Text("Camera")),
                          TextButton(
                              onPressed: () async {
                                image = await _picker.pickImage(source: ImageSource.gallery);
                                setState(() {
                                  t = true;
                                });
                                Navigator.pop(context);
                              },
                              child: Text("Gallery")),
                        ],
                      );
                    },
                  );
                },
                child: Text("Upload")),
            Container(
              height: 200,
              width: 200,
              child: (t==true) ? Image.file(File(image!.path)) : Image.memory(base64Decode(widget.image)) ,
            ),
            ElevatedButton(onPressed: () async {
                String name,contact,img,qry;
                int r_id;
                name=t1.text;
                contact=t2.text;
                img=base64Encode(await image!.readAsBytes());
                qry="update contact_book set name='$name',contact='$contact',image='$img' where id='${widget.id}'";
                print(qry);
                r_id=await widget.database.rawUpdate(qry);
                if(r_id==1)
                  {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                      return second(widget.database);
                    },));
                  }
                else
                  {
                    print("can't update");
                  }

            }, child: Text("update")),
          ],
        ),
      ),
    );
  }
}
