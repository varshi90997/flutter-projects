import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:img_database/second.dart';
import 'package:path/path.dart';
import 'dart:io';
import 'package:sqflite/sqflite.dart';

void main() {
  runApp(MaterialApp(
    home: first(),
  ));
}

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  ImagePicker _picker = ImagePicker();
  XFile? image;
  bool t = false;
  Database? database;

  @override
  void initState() {
    super.initState();
    create_data();
  }

  create_data() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'demo.db');
    database = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(
              'CREATE TABLE contact_book (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact  TEXT,image TEXT)');
        });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: t1,
                  decoration: InputDecoration(hintText: "Enter Name"),
                ),
                SizedBox(
                  height: 25,
                ),
                TextField(
                  controller: t2,
                  decoration: InputDecoration(hintText: "Enter Contact"),
                ),
                SizedBox(
                  height: 25,
                ),
                TextButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: Text("Select Camera Or Gallery"),
                            actions: [
                              TextButton(
                                  onPressed: () async {
                                    image = await _picker.pickImage(
                                        source: ImageSource.camera);
                                    setState(() {
                                      t = true;
                                    });
                                    Navigator.pop(context);
                                  },
                                  child: Text("Camera")),
                              TextButton(
                                  onPressed: () async {
                                    image = await _picker.pickImage(source: ImageSource.gallery);
                                    setState(() {
                                      t = true;
                                    });
                                    Navigator.pop(context);
                                  },
                                  child: Text("Gallery")),
                            ],
                          );
                        },
                      );
                    },
                    child: Text("Upload")),
                Container(
                  height: 200,
                  width: 200,
                  child: (t==true) ? Image.file(File(image!.path)) : Icon(Icons.supervised_user_circle) ,
                ),
                ElevatedButton(onPressed: () async {
                  String str1,str2,img,qry;
                  str1=t1.text;
                  str2=t2.text;
                  img=base64Encode(await image!.readAsBytes());
                  qry="insert into contact_book values(null,'$str1','$str2','$img')";
                  print(qry);
                  int r_id=await database!.rawInsert(qry);
                  print(r_id);
                  t1.text="";
                  t2.text="";
                  img ="";
                }, child: Text("Submit")),
                ElevatedButton(onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return second(database!);
                        },));
                }, child: Text("View Data")),
              ],
            ),
          )),
    );
  }
}
