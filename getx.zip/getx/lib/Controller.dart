import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class Controller extends GetxController
{
  RxInt ans=0.obs;//repeat no karvu pade aena mate setstate ni jgyaye
  RxString fsfjk="jh".obs;
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();

  void sum(String a,String b)
  {
    ans.value=int.parse(a)+int.parse(b);
  }
}