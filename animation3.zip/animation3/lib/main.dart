import 'package:animation3/drop.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {

  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  int t=0;
  bool animation=false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
      Future.delayed(Duration(seconds: 2)).then((value){
      setState(() {
          animation=!animation;
      });
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: AnimatedOpacity(
          opacity: animation?0.5:1,
          duration: Duration(seconds: 1),
          onEnd: () {
            setState(() {
              animation=!animation;
              t++;
            });
            if(t>=4)
              {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return drop();
                },));
              }
          },
          curve: Curves.easeInOutCirc,
          child: Container(
            height: 100,
            width: 100,
            color: Colors.blue,
          ),
        ),
      ),
    );
  }
}
