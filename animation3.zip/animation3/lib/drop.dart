import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class drop extends StatefulWidget {
  const drop({Key? key}) : super(key: key);

  @override
  State<drop> createState() => _dropState();
}

class _dropState extends State<drop> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:ListView(
        children: [
            Lottie.network('https://assets7.lottiefiles.com/packages/lf20_mGXMLaVUoX.json'),
        ],
      )
    );
  }
}
