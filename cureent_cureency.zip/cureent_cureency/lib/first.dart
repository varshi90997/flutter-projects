import 'package:flutter/material.dart';
import 'package:currency_picker/currency_picker.dart';


class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {


  Color background = Colors.white54;
  TextEditingController value=TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black54,
        title: Text(
          "Country Currency",
          style: TextStyle(
              fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: Container(
        color: Colors.black54,
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Container(
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("img/f1.jpg"),fit: BoxFit.cover)),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                    children: [
                      SizedBox(height: 10,),
                      TextField(
                        style: TextStyle(color: Colors.white),
                        controller: value,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.black54,
                          labelText: "Enter Amount",
                          labelStyle: TextStyle(color: Colors.white),
                          ),
                        keyboardType:TextInputType.number,
                      ),
                      SizedBox(height: 10,),
                      TextField(
                        style: TextStyle(color: Colors.white),
                        controller: value,
                        decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.black54,
                          labelText: " Answer",
                          border: OutlineInputBorder(),
                            labelStyle: TextStyle(color: Colors.white)
                        ),
                        keyboardType:TextInputType.number,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          ElevatedButton(onPressed: () {
                            showCurrencyPicker(
                              context: context,
                              showFlag: true,
                              showSearchField: true,
                              showCurrencyName: true,
                              showCurrencyCode: true,
                              onSelect: (Currency currency) {
                                print('Select currency: ${currency.name}');
                              },
                              favorite: ['SEK'],
                            );

                          }, child:Text('Currency')),
                          FloatingActionButton(child:Icon(Icons.swap_horiz_sharp,color: Colors.white,),

                            onPressed: () {},

                          ),
                          ElevatedButton(onPressed: () {
                            showCurrencyPicker(
                              context: context,
                              showFlag: true,
                              showSearchField: true,
                              showCurrencyName: true,
                              showCurrencyCode: true,
                              onSelect: (Currency currency) {
                                print('Select currency: ${currency.name}');
                              },
                              favorite: ['SEK'],
                            );

                          }, child:Text('Currency')),
                        ],
                      ),
                      SizedBox(height: 10,),

                      Padding(
                        padding: EdgeInsets.all(10),
                        child: Container(
                          height: 50,
                          width: double.infinity,
                          color: Colors.black54,
                          child: Center(child: Text("Click",style: TextStyle(color: Colors.white),)),

                        ),
                      ),

                    ]



                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
