import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:loginapi/second.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();

  void login(String email ,String password) async {

    try{

      var url = Uri.parse('https://reqres.in/api/login');
      var response = await http.post(url, body: {'email': email, 'password': password});
      print(password);

      if(password=="pistol" && email=="eve.holt@reqres.in")
      {
        var data = jsonDecode(response.body.toString());
        print(data['token']);
        print('Login successfully');
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return second();
        },));
      }

    }catch(e){
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(child: Column(children: [
        SizedBox(height: 20,),
        TextField(
          controller: t1,
        ),
        SizedBox(height: 20,),
        TextField(
          controller: t2,
        ),

       GestureDetector(
         onTap: () {
           login(t1.text.toString(),t2.text.toString());
         },
         child: Container(
           height: 60,
           width: 200,
           child: Center(child: Text("Login")),
         ),
       )
      ],)),
    );
  }
}
