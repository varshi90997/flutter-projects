import 'package:flutter/material.dart';
import 'package:tic_tac_toe/first.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}