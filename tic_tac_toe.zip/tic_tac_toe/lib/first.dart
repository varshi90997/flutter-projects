import 'dart:math';

import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  String p1 = "o";
  String p2 = "x";
  List<String> l = List.filled(9, "");

  List<int> tl=[];
  int t=0;
  String msg="game is running";
  bool winner=true;
  // int random=0;

  // @override
  // void initState() {
  //   int min=0;
  //   int max=10;
  //   random=Random().nextInt(max-min)+min;
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 100,
            child: Container(
              color: Colors.orange,
              alignment: Alignment.center,
              child: Text("${msg}",style: TextStyle(fontSize: 20)),
            ),
          ),
          Expanded(
              child: Row(
            children: [
              ver(0),
              ver(1),
              ver(2),
            ],
          )),
          Expanded(
              child: Row(
            children: [
              ver(3),
              ver(4),
              ver(5),
            ],
          )),
          Expanded(
              child: Row(
            children: [
              ver(6),
              ver(7),
              ver(8),
            ],
          )),
          SizedBox(
            height: 100,
            child: Container(
              color: Colors.orange,
              // width: 200,
              alignment: Alignment.center,
             child: ElevatedButton(onPressed: () {
               setState(() {
                 l = List.filled(9, "");
                 tl=[];
                 t=0;
                 msg="game is running";
                 winner=true;
               });
             }, child: Text("reset")),
            ),
          ),
        ],
      ),
    );
  }

  ver(int i) {
    return Expanded(
        child: Container(
      height: 100,
      child: InkWell(
        onTap: () {
          setState(() {
            if(l[i]==""&&winner==true)
              {
                l[i]=p1;
                tl.add(i);
                t++;
                win();
                if(t<=4&&winner==true)
                {
                  while(true)
                  {
                    int random=Random().nextInt(9);
                    print(random);
                    if(!tl.contains(random))
                    {
                      l[random]=p2;
                      tl.add(random);
                      win();
                      break;
                    }
                  }
                }
              }
          });

        },
        child: Container(
          // height: 100,
          alignment: Alignment.center,
          color: Colors.deepOrange,
          margin: EdgeInsets.all(10),
          child: Text(l[i], style: TextStyle(fontSize: 40)),
        ),
      ),
    ));
  }
  win()
  {
    if(l[0] == p1 &&l[1] == p1 && l[2] == p1 || 
        l[3] == p1 &&l[4] == p1 && l[5] == p1 ||
        l[6] == p1 &&l[7] == p1 && l[8] == p1 ||
        l[0] == p1 &&l[3] == p1 && l[6] == p1 ||
        l[1] == p1 &&l[4] == p1 && l[7] == p1 ||
        l[2] == p1 &&l[5] == p1 && l[8] == p1 ||
        l[0] == p1 &&l[4] == p1 && l[8] == p1 ||
        l[2] == p1 &&l[4] == p1 && l[6] == p1)
      {
        msg=" $p1 is winner";
        winner=false;

      }
    else if(l[0] == p2 &&l[1] == p1 && l[2] == p1 ||
        l[3] == p2 &&l[4] == p2 && l[5] == p1 ||
        l[6] == p2 &&l[7] == p2 && l[8] == p1 ||
        l[0] ==p2 &&l[3] == p2 && l[6] == p1 ||
        l[1] == p2 &&l[4] == p2 && l[7] == p1 ||
        l[2] == p2 &&l[5] == p2 && l[8] == p1 ||
        l[0] ==p2 &&l[4] == p2 && l[8] == p1 ||
        l[2] == p2 &&l[4] == p2 && l[6] == p1)
    {
      msg=" $p2 is winner";
      winner=false;
    }
    else if(t>8)
      {
        msg="draw";
        winner=false;
      }

  }
}
