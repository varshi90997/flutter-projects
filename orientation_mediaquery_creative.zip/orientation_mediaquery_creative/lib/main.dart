import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main()
{
  // SystemChrome.setPreferredOrientations([
  //   DeviceOrientation.portraitUp,//search in google in stack overflow====Flutter: how to prevent device orientation changes and force portrait?
  //   DeviceOrientation.portraitDown
  // ]);
  runApp(MaterialApp(home: first()));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  @override
  Widget build(BuildContext context) {
    return OrientationBuilder(builder: (context, orientation) {
      print(orientation);

      if(orientation==Orientation.landscape)
        {
          return Scaffold(
            appBar: AppBar(),
            body: Container(
              height: 100,
              width: 100,
              color: Colors.amber,
            ),
          );
        }
      else
        {
          return Scaffold(
            appBar: AppBar(),
            body: Container(
              height: 200,
              width: 200,
              color: Colors.red,
            ),
          );
        }
    },);
  }
}
