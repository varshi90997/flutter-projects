import 'package:flutter/material.dart';
import 'package:mediaquiry/first.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}