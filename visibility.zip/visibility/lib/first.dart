import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  List imglist = [
    "bananas.png",
    "dragon-fruit.png",
    "mango.png",
    "orange.png",
    "passion-fruit.png",
    "watermelon.png",
    "bananas.png",
    "dragon-fruit.png",
    "mango.png",
    "orange.png",
    "passion-fruit.png",
    "watermelon.png"
  ];
  List visiblelist = List.filled(12, true);
  int t = 1;
  String img1 = "", img2 = "";
  int pos1 = 0, pos2 = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    imglist.shuffle();
    Future.delayed(Duration(seconds: 3)).then((value) {
      setState(() {
        visiblelist = List.filled(12, 0false);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(backgroundColor: Colors.redAccent),
      body: Container(
        decoration: BoxDecoration(image:DecorationImage(image: AssetImage("assset/f11.jpg"),fit: BoxFit.cover)),
        child: Column(
          children: [
            Expanded(
              child: GridView.builder(
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        setState(() {
                          if(t==1)
                            {
                              print("first click");
                              visiblelist[index]=true;
                              img1=imglist[index];
                              pos1=index;
                              t=2;
                            }
                          else if(t==2)
                          {
                            print("secondclick");
                            visiblelist[index]=true;
                            img2=imglist[index];
                            pos2=index;
                            t=1;
                            if(img1==img2)
                              {
                                print("match");
                                if(!visiblelist.contains(false))
                                {
                                  print("win");
                                  showDialog( builder: (context) {
                                    return AlertDialog(
                                      title: Text("you are win"),
                                      actions: [
                                        TextButton(onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                                            return first();
                                          },));
                                        }, child: Text("restart"))
                                      ],
                                    );
                                  },context: context);
                                }
                              }
                            else
                            {
                              Future.delayed(Duration(milliseconds: 500)).then((value) {
                                setState(() {
                                  visiblelist[pos1]=false;
                                  visiblelist[pos2]=false;
                                  print("not match");
                                });
                              });
                            }
                          }
                        });
                      },
                      child: Visibility(
                          visible: visiblelist[index],
                          child: Image.asset("assset/${imglist[index]}",height: 100,width: 100,),
                          replacement: Container(height: 100,width: 100,color: Colors.white60),
                      ),
                    );
                  },
                  gridDelegate:
                      SliverGridDelegateWithFixedCrossAxisCount(mainAxisExtent: 130,crossAxisCount: 3,childAspectRatio: 2,crossAxisSpacing: 10,mainAxisSpacing: 10),
                  itemCount: imglist.length,),
            ),
            Container(height: 150,width: 100,color: Colors.white60,child:ElevatedButton(onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return first();
              },));
              }, child: Text("restart")),)

          ],
        ),
      ),
    );
  }
}
