import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  var data;
  Future<void> getuserapi()async
  {
    var url = Uri.parse('https://jsonplaceholder.typicode.com/posts');
    var response = await http.get(url);
    
    if(response.statusCode ==200)
      {
        data=jsonDecode(response.body.toString());
      }
    else
      {
        Center(child: CircularProgressIndicator(),);
      }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Complex api")),
      body: Column(
        children: [
                  Expanded(child: FutureBuilder(future: getuserapi(),builder: (context, snapshot) {
                    if(snapshot.connectionState==ConnectionState.waiting)
                      {
                        return Text("Loading");
                      }
                    else
                      {
                        return ListView.builder(itemCount: data.length,itemBuilder: (context, index) {
                          return Card(

                            child: Column(
                              children: [
                                Reusablerow(title: 'title', value: data[index]['title'].toString()),

                                // Reusablerow(title: 'username', value: data[index]['username'].toString()),
                              ],
                            ),);
                        },);
                      }
                  },))
        ],
      ),
    );
  }
}
class Reusablerow extends StatelessWidget {
  String title,value;

  Reusablerow({Key? key ,required this.title,required this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [

        Text(title),
        Text(value),
      ],
    );
  }
}

