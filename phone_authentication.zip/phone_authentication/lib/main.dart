import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:phone_authentication/second.dart';

Future<void> main()

async { WidgetsFlutterBinding.ensureInitialized();
await Firebase.initializeApp(
  // options: DefaultFirebaseOptions.currentPlatform,
);
  runApp(MaterialApp(home: first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  FirebaseAuth auth = FirebaseAuth.instance;
  String ?id;

  TextEditingController t1=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(children: [
        TextField(controller: t1,),
        ElevatedButton(onPressed: () async {       /////website-https://firebase.flutter.dev/docs/auth/phone
          await FirebaseAuth.instance.verifyPhoneNumber(
            phoneNumber: '+91${t1.text}',
            verificationCompleted: (PhoneAuthCredential credential) async {
              await auth.signInWithCredential(credential);//1- signin karvano
            },
            verificationFailed: (FirebaseAuthException e) {//1-2 verification failed thay to
                if (e.code == 'invalid-phone-number') {
                  print('The provided phone number is not valid.');
                }
            },
            codeSent: (String verificationId, int? resendToken) {//1-3 code send karva mate
              id=verificationId;
            },
            codeAutoRetrievalTimeout: (String verificationId) {},//1-4 ketla time ma code in valide thay jay
          );
        }, child: Text("otp")),
        OtpTextField(                   ////otp in flutter--->https://pub.dev/packages/flutter_otp_text_field
          numberOfFields: 6,
          borderColor: Color(0xFF512DA8),
          //set to true to show as box or false to show as dash
          showFieldAsBox: true,
          //runs when a code is typed in
          onCodeChanged: (String code) {
            //handle validation or checks here           
          },
          //runs when every textfield is filled
          onSubmit: (String verificationCode) async {//2-textfield and google na message ne sarkhave same hoy toj biju pagr ave
                                                        ////https://firebase.flutter.dev/docs/auth/phone---->link ma 4thu

            String smsCode = verificationCode;

            // Create a PhoneAuthCredential with the code
            PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: id!, smsCode: smsCode);

            // Sign the user in (or link) with the credential
            await auth.signInWithCredential(credential).then((value)  {
              if(value!=null)
                {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return second();
                  },));
                }
            });
          }, // end onSubmit
        ),
        ElevatedButton(onPressed: () {
          
        }, child: Text("submit"))
      ]),
    );
  }
}
