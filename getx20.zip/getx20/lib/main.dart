import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'first.dart';

void main()
{
  runApp(GetMaterialApp( home:first(),));
}