import 'package:get/get.dart';

class controller{

  RxInt cnt = 0.obs;
  RxList<String> l = List.filled(9, "").obs;
  RxList templist = [].obs;
  RxString msg = "Game is running".obs;

}