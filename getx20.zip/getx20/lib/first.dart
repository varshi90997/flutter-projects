import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:getx20/controller.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  controller c=Get.put(controller());
  String p1 = "O";
  String p2 = "X";
  bool w=true;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("Tic-Tac-Toe"),
      ),
      body: Column(
        children: [
          Expanded(
              child: Row(
            children: [
              Expanded(
                  child: Container(
                    height: double.infinity,
                color: Colors.amber,
                alignment: Alignment.center,
                margin: EdgeInsets.all(10),
                    child: Obx(() => Text("${c.msg}")),
              )),

            ],
          )),
          Expanded(
              child: Row(
                children: [
                  Obx(() => box(0),),
                  Obx(() => box(1),),
                  Obx(() => box(2),),
                ],
              )),
          Expanded(
              child: Row(
            children: [
              Obx(() => box(3),),
              Obx(() => box(4),),
              Obx(() => box(5),),

            ],
          )),
          Expanded(
              child: Row(
            children: [
              Obx(() => box(6),),
              Obx(() => box(7),),
              Obx(() => box(8),),
            ],
          )),
          ElevatedButton(onPressed: () {

              c.cnt.value = 0;
              c.l.value = List.filled(9, "");
              c.templist.value = [];
              c.msg.value = "Game Is Running";
              w=true;

          }, child: Text("RESET")),

        ],
      ),
    );
  }

  box(int i) {
    return Expanded(
      child: InkWell(
        onTap: () {

          // setState(() {
          //   print("object");
          // });
            if(c.cnt%2==0 && c.l[i]=="" && w==true){

              c.l[i] = p1;
              print(c.l[i]);
              c.templist.add(i);
              c.cnt++;
              win();
              // if (cnt <= 4 && w==true) {
              //   while (true) {
              //     int random = Random().nextInt(9);
              //     if (!templist.contains(random)) {
              //       l[random] = p2;
              //       templist.add(random);
              //       win();
              //       break;
              //     }
              //   }
              // }
            }
            else if(c.cnt%2==1 && c.l[i]=="" && w==true){
              c.l[i]=p2;
              c.templist.add(i);
              c.cnt++;
              win();
            }
            // if (l[i] == "" && w==true) {
            //
            // }
            // if(l[i]=="" && w==true){
            //
            // }

        },
        child: Container(
          color: Colors.amberAccent,
          alignment: Alignment.center,
          margin: EdgeInsets.all(10),
          child: Text(
            c.l[i],
            style: TextStyle(fontSize: 50),
          ),
        ),
      ),
    );
  }

  win() {
    if ((c.l[0] == p1 && c.l[1] == p1 && c.l[2] == p1) ||
        (c.l[3] == p1 && c.l[4] == p1 && c.l[5] == p1) ||
        (c.l[6] == p1 && c.l[7] == p1 && c.l[8] == p1) ||
        (c.l[0] == p1 && c.l[3] == p1 && c.l[6] == p1) ||
        (c.l[1] == p1 && c.l[4] == p1 && c.l[7] == p1) ||
        (c.l[2] == p1 && c.l[5] == p1 && c.l[8] == p1) ||
        (c.l[0] == p1 && c.l[4] == p1 && c.l[8] == p1) ||
        (c.l[2] == p1 && c.l[4] == p1 && c.l[6] == p1)) {
      c.msg.value = "${p1} is win";
      w=false;
    } else if ((c.l[0] == p2 && c.l[1] == p2 && c.l[2] == p2) ||
        (c.l[3] == p2 && c.l[4] == p2 && c.l[5] == p2) ||
        (c.l[6] == p2 && c.l[7] == p2 && c.l[8] == p2) ||
        (c.l[0] == p2 && c.l[3] == p2 && c.l[6] == p2) ||
        (c.l[1] == p2 && c.l[4] == p2 && c.l[7] == p2) ||
        (c.l[2] == p2 && c.l[5] == p2 && c.l[8] == p2) ||
        (c.l[0] == p2 && c.l[4] == p2 && c.l[8] == p2) ||
        (c.l[2] == p2 && c.l[4] == p2 && c.l[6] == p2)) {
      c.msg.value = "${p2} is win";
      w=false;
    }
  }
}
