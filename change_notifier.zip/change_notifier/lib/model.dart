import 'package:flutter/cupertino.dart';

class model extends ChangeNotifier //2-Extend karavvy pade
{
    TextEditingController t1=TextEditingController();//-all logic and function ahiya ave getx ni jem EX no lghavvu pade
    TextEditingController t2=TextEditingController();

    int sum=0;
    void sums(String a,String b)
    {
      sum=int.parse(a)+int.parse(b);
      notifyListeners();
    }
}