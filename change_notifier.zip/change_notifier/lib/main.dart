import 'package:change_notifier/model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
//only # step require
void main()
{
  runApp(MaterialApp(home: ChangeNotifierProvider(//3-provider nakhvu pade
      create: (context) => model(),//logic valo
    child: first(),//simple

  )));
}
class first extends StatelessWidget {
  const first({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {


    model m=Provider.of(context);//1-object bnavyo
    return Scaffold(
      appBar: AppBar(),
      body: Column(children: [

        TextField(controller: m.t1,),
        TextField(controller: m.t2,),
        ElevatedButton(onPressed: () {
          m.sums(m.t1.text,m.t2.text);
        }, child: Text("Sum")),

        Text("${m.sum}")
      ]),
    );
  }
}

