import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  double l=0;
  String p="0";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("BMI CALCULATOR")),
      body: Column(
        children: [
          SizedBox(height: 50),
          Container(
            margin: EdgeInsets.all(10),
            child: TextField(
            // obscureText: true,
            controller: t1,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              // labelText: 'Password',
              hintText: 'WAIGHT',
            ),
            ),
          ),
          Container(
            margin: EdgeInsets.all(10),
            child: TextField(
              // obscureText: true,
              controller: t2,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                // labelText: 'Password',
                hintText: 'HEIGHT',
              ),
            ),
          ),
          SizedBox(height: 20,),
          Container(
            width: 100,
            child: ElevatedButton(onPressed: () {
                String a=t1.text;
                String b=t2.text;
                // print(a);
                // print(b);

                double n1=double.parse(a);
                // double n3=double.parse(source)
                double n2=double.parse(b);
                // int n=n1+n2;

                double h=3.2808;
                double m=n2/h;
                print(m);


                double h2=m*m;
                double m2=n1/h2;
                print(m2);
                setState(() {
                          l=m2;
                });
                if(l<=18.4)
                  {
                    p="underweight";
                  }
                else if(l>=18.5&&l<=24.9)
                  {
                    p="normal";
                  }
                else if(l>=25.0&&l<=39.9)
                {
                  p="overwight";
                }
                else
                {
                  p="obese";
                }
                setState(() {
                });
            }, child: Text("Calculate")),
          ),
          SizedBox(height: 20,),
          Container(
              height:50,
              alignment: Alignment.center,
              width: 100,
              color: Colors.black54,
              child: Text("${l}"),
          ),
          SizedBox(height: 20,),
          Container(
              alignment: Alignment.center,
              height:50,
              width: 100,
              color: Colors.black54,
              child: Text("${p}"),

          ),

        ],

      ),
    );
  }

}
