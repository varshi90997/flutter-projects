import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Container(
          height: 755,
          width: 400,
          color: Colors.white,
          child: Stack(
            children: [
              Container(
                height:350,
                width: 400,
                color: Color(0xff850E10),
              ),
              Padding(
                padding: EdgeInsets.only(left: 10,top: 200),
                child: Container(
                  height:550,
                  width: 330,
                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20), boxShadow: [
                    BoxShadow(
                    blurRadius: 15.0,
                  ),
                ],),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 110,top: 160),
                child: Container(
                  height:120,
                  width: 120,
                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20), boxShadow: [
                    BoxShadow(
                    blurRadius: 12.0,
                  ),
                ],),
                  child: Center(child: Text("",style: TextStyle( color: Color(0xff850E10),fontSize: 40,fontWeight: FontWeight.bold)), )
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 40,top: 290),
                child: Container(
                  height:40,
                  width: 280,
                  decoration: BoxDecoration(color: Colors.transparent,borderRadius: BorderRadius.circular(20)),
                    child: Center(child: Text("Create a  New Account",style: TextStyle( color: Color(0xff0C1D40),fontSize: 30,fontWeight: FontWeight.bold)), )
                ),
              ),

              Padding(
                padding: EdgeInsets.only(left: 120,top: 330),
                child: Container(
                  height:20,
                  width: 120,
                  decoration: BoxDecoration(color: Colors.transparent,borderRadius: BorderRadius.circular(20)),
                    child: Center(child: Text("It’s quickly and easy",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)), )

                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 20,top: 380),
                child: Container(
                  height:50,
                  width: 150,
                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20),border: Border.all(color: Colors.black,width: 1)),
                  child: Row(children: [
                    SizedBox(width: 10,),
                    Icon(Icons.supervised_user_circle_rounded),
                    SizedBox(width: 10,),
                    Text("First Name",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                  ]),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 175,top: 380),
                child: Container(
                  height:50,
                  width: 150,
                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20),border: Border.all(color: Colors.black,width: 1)),
                  child: Row(children: [
                    SizedBox(width: 10,),
                    Icon(Icons.supervised_user_circle_rounded),
                    SizedBox(width: 10,),
                    Text("First Name",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                  ]),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 20,top: 440),
                child: Container(
                  height:50,
                  width: 310,
                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20),border: Border.all(color: Colors.black,width: 1)),
                  child: Row(children: [
                    SizedBox(width: 10,),
                    Icon(Icons.calendar_month_outlined),
                    SizedBox(width: 10,),
                    Text("First Name",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                    SizedBox(width: 160,),
                    Icon(Icons.calendar_month_outlined,color: Colors.red),
                  ]),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 20,top: 510),
                child: Container(
                  height:50,
                  width: 310,
                  decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(20),border: Border.all(color: Colors.black,width: 1)),
                  child: Row(children: [
                    SizedBox(width: 10,),
                    Icon(Icons.transgender),
                    SizedBox(width: 10,),
                    Text("First Name",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                    SizedBox(width: 160,),
                    Icon(Icons.arrow_drop_down_sharp,size: 40),
                  ]),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 20,top: 580),
                child: Container(
                  height:60,
                  width: 310,
                  decoration: BoxDecoration(color: Color(0xff850E10),borderRadius: BorderRadius.circular(20),),
                  child: Row(children: [
                    SizedBox(width: 120,),

                    Text("Sign up",style: TextStyle( color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold)),
                    SizedBox(width: 10,),
                    Icon(Icons.arrow_forward_rounded,size: 30),
                  ]),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 40,top: 640),
                child: Container(
                  height:30,
                  width: 290,
                  decoration: BoxDecoration(color: Colors.transparent,borderRadius: BorderRadius.circular(20)),
                  child: Row(
                    children: [
                      Text("Already have an account?",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 20,fontWeight: FontWeight.bold)),
                      Text(" Login",style: TextStyle( color: Colors.red,fontSize: 20,fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 20,top: 670),
                child: Container(
                  height:50,
                  width: 320,
                  decoration: BoxDecoration(color: Colors.transparent,borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text("By clicking Sign Up, you agreed to our?",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                          Text(" Terms, Privacy",style: TextStyle( color: Colors.red,fontSize: 15,fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Row(
                        children: [
                          Text("and Cookies Policy",style: TextStyle( color: Colors.red,fontSize: 15,fontWeight: FontWeight.bold)),
                          Text("You may receive SMS notifications",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 70,top: 700),
                child: Container(
                  height:30,
                  width: 290,
                  decoration: BoxDecoration(color: Colors.transparent,borderRadius: BorderRadius.circular(20)),
                  child: Row(
                    children: [
                      Text("from us and can otp out at any time.",style: TextStyle( color: Color(0xff7E7E7E),fontSize: 15,fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),

            ],
          ),
        )
      ]),
    );
  }
}
