import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:flutter/material.dart';
import 'package:notebook_app2/first.dart';
import 'package:share_plus/share_plus.dart';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class second extends StatefulWidget {
  Database? database;

  second(this.database);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  TextEditingController t3 = TextEditingController();
  List<Color> co = [
    Colors.blue,
    Colors.red,
    Colors.green,
    Colors.yellow,
    Colors.amber,
    Colors.orangeAccent,
    Colors.brown,
    Colors.blueGrey,
    Colors.cyanAccent,
    Colors.deepPurple,
    Colors.deepPurpleAccent,
    Colors.cyanAccent,
    Colors.greenAccent,
    Colors.grey,
    Colors.pink,
  ];
  List<Color> co1 = [
    Colors.blueAccent,
    Colors.redAccent,
    Colors.greenAccent,
    Colors.yellowAccent,
    Colors.amberAccent,
    Colors.orangeAccent,
    Colors.brown.shade100,
    Colors.blueGrey.shade100,
    Colors.cyanAccent.shade100,
    Colors.deepPurple.shade100,
    Colors.deepPurpleAccent.shade100,
    Colors.cyanAccent.shade100,
    Colors.greenAccent.shade100,
    Colors.grey.shade100,
    Colors.pink.shade100,

  ];
  List<Color> col = [
    Colors.blueGrey,
    Colors.red,
    Colors.green,
    Colors.yellow,
    Colors.amber,
    Colors.orangeAccent,
    Colors.brown,
    Colors.blueGrey,
    Colors.cyanAccent,
    Colors.deepPurple,
    Colors.deepPurpleAccent,
    Colors.cyanAccent,
    Colors.greenAccent,
    Colors.grey,
    Colors.pink,
  ];

  int i = 0;
  int back = 0;
  int textcol = 0;
  bool bo = false;
  bool io = false;
  bool uo = false;
  bool textbool = false;
  bool bagcolor = false;

  Database? database;
  int t = 15;

  @override
  void initState() {
    super.initState();
    print(widget.database);
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: co1[i],
        title: TextField(
          controller: t1,
          decoration: InputDecoration(
            hintText: "Edit title",
          ),
        ),
        actions: [
          IconButton(
              onPressed: () async {
                String str1, str2, qry;
                str1 = t1.text;
                str2 = t2.text;
                qry =
                    "insert into note(title, content) values('$str1','$str2')";
                int r_id;
                r_id = await widget.database!.rawInsert(qry);
                print("qry = $qry");
                print("id = $r_id");
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return first(widget.database);
                  },
                ));
              },
              icon: Icon(Icons.save)),
          PopupMenuButton(
            itemBuilder: (context) => [
              PopupMenuItem(
                  child: Row(
                children: [
                  Container(
                      color: Colors.white,
                      child: Icon(
                        Icons.push_pin,
                        color: Colors.black,
                      )),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Pin"),
                ],
              )),
              PopupMenuItem(
                  child: Row(
                children: [
                  Container(
                      color: Colors.white,
                      child: IconButton(onPressed: () {
                        String str1,str2;
                        str1=t1.text;
                        str2=t2.text;


                        Share.share('check out my website https://example.com');
                      }, icon: Icon(Icons.share,color: Colors.black,)),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text("share"),
                ],
              )),
              PopupMenuItem(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      Container(
                          color: Colors.white,
                          child: Icon(
                            Icons.delete,
                            color: Colors.black,
                          )),
                      SizedBox(
                        width: 10,
                      ),
                      Text("Delete"),
                    ],
                  ))
            ],
          )
        ],
      ),
      body: Container(
          height: double.infinity,
          width: double.infinity,
          color: co[i],
          child: TextField(
            maxLines: 500,
            controller: t2,
            decoration: InputDecoration(hintText: "No content"),
            style: TextStyle(
              fontSize: t.toDouble(),
              color: textbool ? co[textcol] : Colors.black,
              backgroundColor: bagcolor ? col[back] : Colors.transparent,
              fontWeight: bo ? FontWeight.bold : FontWeight.normal,
              fontStyle: io ? FontStyle.italic : FontStyle.normal,
              decoration: uo ? TextDecoration.underline : TextDecoration.none,
            ),
          )),
      bottomNavigationBar: SizedBox(
        height: 50,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(
                onPressed: () => boot(context),
                icon: Icon(Icons.color_lens_outlined)),
            IconButton(
                onPressed: () {
                  bo = !bo;
                  print(bo);
                  setState(() {});
                },
                icon: Icon(Icons.format_bold)),
            IconButton(
                onPressed: () {
                  io = !io;
                  setState(() {});
                },
                icon: Icon(Icons.format_italic)),
            IconButton(
                onPressed: () {
                  uo = !uo;
                  setState(() {});
                },
                icon: Icon(Icons.format_underline)),
            IconButton(
                onPressed: () => backgroun(context),
                icon: Icon(Icons.format_color_text)),
            InkWell(
              onTap: () {
                textcolor(context);
              },
              child: Container(
                height: 30,
                width: 30,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  border: GradientBoxBorder(
                      gradient: LinearGradient(colors: [
                    Colors.red,
                    Colors.orange,
                    Colors.yellow,
                    Colors.green,
                    Colors.cyan,
                    Colors.blue,
                    Colors.purple
                  ])),
                  color: Colors.black,
                ),
              ),
            ),
            DropdownButton(
                value: t.toDouble(),
                onChanged: (value) {
                  setState(() {
                    print("$t");
                    t = value as int;
                  });
                },
                items: [
                  DropdownMenuItem(
                    child: Text("30"),
                    value: 30,
                  ),
                  DropdownMenuItem(child: Text("25"), value: 25),
                  DropdownMenuItem(child: Text("20"), value: 20),
                  DropdownMenuItem(child: Text("15"), value: 15),
                  DropdownMenuItem(child: Text("10"), value: 10),
                  DropdownMenuItem(child: Text("5"), value: 5),
                ])
          ],
        ),
      ),
    );
  }

  textcolor(BuildContext context) {
    return showModalBottomSheet(
        builder: (context) {
          return Container(
            height: 300,
            width: 100,
            color: Colors.white,
            child: Row(
              children: [
                Expanded(
                  child: GridView.builder(
                      itemCount: co.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              textbool = true;
                              textcol = index;
                              print(textbool);
                            });
                          },
                          child: Container(
                            height: 100,
                            width: 100,
                            margin: EdgeInsets.all(20),
                            color: co[index],
                          ),
                        );
                      },
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 5)),
                ),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.close)),
              ],
            ),
          );
        },
        context: context);
  }

  boot(BuildContext context) {
    return showModalBottomSheet(
        builder: (context) {
          return Container(
            height: 300,
            width: 100,
            color: Colors.white,
            child: Row(
              children: [
                Expanded(
                  child: GridView.builder(
                      itemCount: co.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              i = index;
                            });
                          },
                          child: Container(
                            height: 100,
                            width: 100,
                            margin: EdgeInsets.all(20),
                            color: co[index],
                          ),
                        );
                      },
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 5)),
                ),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.close)),
              ],
            ),
          );
        },
        context: context);
  }

  backgroun(BuildContext context) {
    return showModalBottomSheet(
        builder: (context) {
          return Container(
            height: 300,
            width: 100,
            color: Colors.white,
            child: Row(
              children: [
                Expanded(
                  child: GridView.builder(
                      itemCount: co.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              bagcolor = true;
                              back = index;
                              print("bagcolor=$bagcolor");
                            });
                          },
                          child: Container(
                            height: 100,
                            width: 100,
                            margin: EdgeInsets.all(20),
                            color: co[index],
                          ),
                        );
                      },
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 5)),
                ),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.close)),
              ],
            ),
          );
        },
        context: context);
  }
}
