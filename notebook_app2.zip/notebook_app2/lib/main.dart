import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:notebook_app2/first.dart';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as Path;

void main(){
  runApp(MaterialApp(home: demo(),));
}


class demo extends StatefulWidget {
  const demo({Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {
  Database? database;
  @override
  void initState() {
    super.initState();
    creact();
    get();
  }
  get() async {
    await Future.delayed(Duration(seconds: 1));
    Navigator.push(context, MaterialPageRoute(builder: (context) {
       return first(database);
    },));
  }
  creact() async {
    var databasesPath = await getDatabasesPath();
    String path = Path.join(databasesPath, 'demo.db');
    database = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(
              'CREATE TABLE note (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT)');
        });
    print("database = $database");
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.green,
      ),
    );
  }
}

